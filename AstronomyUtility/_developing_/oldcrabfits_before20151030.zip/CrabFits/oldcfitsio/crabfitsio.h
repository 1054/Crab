#ifndef CRABFITSIO_H
#define CRABFITSIO_H

class CrabFitsIO
{
public:
    CrabFitsIO();
    void openFits();
};

#endif // CRABFITSIO_H
