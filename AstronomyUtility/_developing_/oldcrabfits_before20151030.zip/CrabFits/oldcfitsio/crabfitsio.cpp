#include "crabfitsio.h"
#include "fitsio.h"

CrabFitsIO::CrabFitsIO()
{
}

void CrabFitsIO::openFits()
{
    /* open file */
    fitsfile *fptr;
    fits_create_file(&fptr, "/Users/dliu/Programming/QtProgram/AstronomyUtility/CrabFits/test_FIT_goodsn_250_Map_201407.fits", &status);

    int status, ii, jj;
    long fpixel = 1, naxis = 2, nelements, exposure;
    long naxes[2] = { 300, 200 }; /* image is 300 pixels wide by 200 rows */
    short array[200][300];
    status = 0; /* initialize status before calling fitsio routines */
    /* Create the primary array image (16-bit short integer pixels */
    fits_create_img(fptr, SHORT_IMG, naxis, naxes, &status);
    ￼/* Write a keyword; must pass the ADDRESS of the value */
    return status;
}
