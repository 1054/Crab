//standard fits header reader.
//standard fits header contains these lines:
// 1. keyword line (number value) (baLine[8]=="=")
// 2. keyword line (string value) (baLine[8]=="=")
// 3. comment line                (baLine[0:6]=="COMMENT")
// 4. history line                (baLine[0:6]=="HISTORY")
// 5. end of header line
#include <stdio.h>
#include <string.h>
#include <malloc.h>
#include "myfitsio.h"



char *readFitsHeader(const char *strFilePath)
{
    int err=0;
    int isHeader=0;    //whether this line is simple text (header).
    int flagENDmark=0; //whether this line is a END marked line.
    int findENDmark=0;    //find and locate the END marked line.
    int findEndline=0;    //find and locate the end line of the entire header.
    int countLines=0; //current line number when dealing with the header. count total header lines.
    char *baLine;     //byte array containing a line.
    char *Data;
    char *Text;
    int i=0, fileSize=0,headerSize=0;
    FILE *fp;
    /*Open the fits file.*/
    fp = fopen(strFilePath,"rb");
    if(fp==NULL)
    {
        err=5; //file not exist. cannot open it.
        return NULL;
    }
    /*Calculate the file size.*/
    fseek(fp,0,SEEK_END);
    fileSize=ftell(fp);
    /*Rewind the file pointer and initial parameters.*/
    fseek(fp,0,SEEK_SET);
    isHeader=1; countLines=0; headerSize=0;
    baLine = (char *)malloc(81*sizeof(char));
    Data = (char *)malloc((fileSize+1)*sizeof(char));
    memset(baLine,0x20,80);
    memset(Data,0x20,fileSize);
    *(baLine+80)='\0';
    *(Data+fileSize)=0x00;
    /*Begin loop.*/
    while(isHeader==1 && !feof(fp))
    {
        /*Read a line.*/
        headerSize += fread(baLine,1,80,fp);
        //if(headerSize%80!=0) {err=52;isHeader=0;break;}
        countLines++;
        /*Classify this line simply.*/
        if(!isSimpleText(baLine))  //this line is not a text line.
            isHeader=0;
        else if(isENDmark(baLine)) //this line is the END marked line.
        {
            flagENDmark=1;
            findENDmark=countLines;
        }
        /*Deal with different types of lines.*/
        if(isHeader!=0)
        {
            for(i=0;i<80;i++)
            {
                *(Data+headerSize-80+i) = *(baLine+i);
            }
        }
        else
        {
            //this is the first time we meet the line that is not a text line.
            findEndline = countLines-1;
            headerSize = headerSize-80;
        }
    }
    /*Malloc result Text Array for output.*/
    Text = (char *)malloc((headerSize+1)*sizeof(char));
    for(i=0;i<headerSize;i++)
    {
        *(Text+i) = *(Data+i);
    }
    *(Text+headerSize)=0x00;
    /*Clean obsolete arrays.*/
    free((void *)baLine);
    free((void *)Data);
    baLine=NULL;
    Data=NULL;
    fclose(fp);
    //printf("this should be 0 ::: %d \n",headerSize-strlen(Text));
    return Text;
}






//find and extract a keyword value.
char *extKeyword(char *strName, char *strHeader)
{
    int err=0;
    int isHeader=0;    //whether this line is simple text (header).
    int flagNumberKeyword=0; //whether this line is a number type keyword line.
    int flagStringKeyword=0; //whether this line is a string type keyword line.
    int flagKeyword=0; //whether this line is a keyword line.
    int flagComment=0; //whether this line is a comment line.
    int flagHistory=0; //whether this line is a history line.
    int flagENDmark=0; //whether this line is a END marked line.
    //int flagEndline=0; //whether this line is the end line of the entire header.
    //int flagQuoted=0;  //whether these chars are quoted by ' '.
    //int findLastKeyword=0;//find and locate the last keyword line.
    //int findLastComment=0;//find and locate the last comment line.
    //int findLastHistory=0;//find and locate the last history line.
    //int findENDmark=0;    //find and locate the END marked line.
    //int findEndline=0;    //find and locate the end line of the entire header.
    int findQuote1=0,findQuote2=0,findSlash=0; //find and locate the ' in a line.
    int countLines=0; //current line number when dealing with the header. count total header lines.
    int countSize =0; //current header size when dealing with the header. count total header size.
    char *strKeywordName;
    char *strKeywordValue;
    char *baLine;    //byte array containing a line.
    int i=0, j=0, headerSize=0, match=-1;
    /*initial parameters.*/
    headerSize=strlen(strHeader);
    isHeader=1; countLines=0; countSize=0;
    baLine = (char *)malloc(81*sizeof(char));
    strKeywordName = (char *)malloc(9*sizeof(char));
    strKeywordValue = (char *)malloc(72*sizeof(char));
    memset(baLine,0x20,80);
    memset(strKeywordName,0x20,8);
    memset(strKeywordValue,0x20,71);
    *(baLine+80)='\0';
    *(strKeywordName+8)=0x00;
    *(strKeywordValue+71)=0x00;
    /*Copy the keyword name.*/
    for(i=0;i<8;i++)
    {
        if(i<strlen(strName))
            *(strKeywordName+i)=*(strName+i);
        else
            *(strKeywordName+i)=0x20;
    }
    /*Begin loop.*/
    while(isHeader==1)
    {
        /*Read in one line.*/
        for(i=0;i<80;i++)
        {
            *(baLine+i) = *(strHeader+countSize+i);
        }
        countSize +=80;
        countLines++;
        /*Classify this line.*/
        flagKeyword=0;flagENDmark=0;flagComment=0;flagHistory=0;
        if(!isSimpleText(baLine))     isHeader=0;
        else if(*(baLine+8)==0x3D) flagKeyword=1; //"=" ASCII is 0x3D.
        else if(isENDmark(baLine)) flagENDmark=1;
        else if(isComment(baLine)) flagComment=1;
        else if(isHistory(baLine)) flagHistory=1;
        /*deal with different type lines.*/
        if(isHeader==0)
        {
            /*header invalid!*/
            err=62;
        }
        else if(flagKeyword==1)
        {
            /*Compare the keyword name.*/
            match = strncmp(baLine,strKeywordName,8);  //case sensitive! TODO:case.
            //match = strncmp(baLine,strKeywordName,8); //case insensitive! TODO:case.
            if(match==0)
            {
                //string type? number type?
                findQuote1=locateQuote(baLine,9,79);
                /*string type. (contains a pair of quote.)*/
                if(findQuote1>=9 && findQuote1<=11)  //TODO: test the position of ' . Is it always 10?
                {
                    flagStringKeyword=1;
                    findQuote2=locateQuote(baLine,findQuote1+1,79);
                    if(findQuote2>findQuote1)
                    for(i=findQuote1;i<=findQuote2;i++)
                    {
                        *(strKeywordValue+i-findQuote1) = *(baLine+i);
                    }
                }
                /*number type. (contains no quote.)*/
                else
                {
                    flagNumberKeyword=1;
                    findSlash=locateSlash(baLine,9,79); //it should be 31 or 32.
                    for(i=9,j=0;i<findSlash;i++)
                    {
                        if(*(baLine+i)!=0x20) //remove blank spaces.
                        {
                            *(strKeywordValue+j) = *(baLine+i);
                            j++;
                        }
                    }
                }
            }
            else
            {
                //
            }
        }
        else if(flagComment==1)
        {
            //
        }
        else if(flagHistory==1)
        {
            //
        }
        else if(flagENDmark==1)
        {
            //
        }
    }
    /*Clean mem.*/
    free((void *)(baLine));
    free((void *)(strKeywordName));
    baLine=NULL;
    strKeywordName=NULL;
    return strKeywordValue;
}




//find and modify a keyword value.
char *modKeyword(char *strName, char *strValue, char *strHeader)
{
    int err=0;
    int isHeader=0;    //whether this line is simple text (header).
    int flagNumberKeyword=0; //whether this line is a number type keyword line.
    int flagStringKeyword=0; //whether this line is a string type keyword line.
    int flagKeyword=0; //whether this line is a keyword line.
    int flagComment=0; //whether this line is a comment line.
    int flagHistory=0; //whether this line is a history line.
    int flagENDmark=0; //whether this line is a END marked line.
    //int flagEndline=0; //whether this line is the end line of the entire header.
    //int flagQuoted=0;  //whether these chars are quoted by ' '.
    //int findLastKeyword=0;//find and locate the last keyword line.
    //int findLastComment=0;//find and locate the last comment line.
    //int findLastHistory=0;//find and locate the last history line.
    //int findENDmark=0;    //find and locate the END marked line.
    //int findEndline=0;    //find and locate the end line of the entire header.
    int findQuote1=0,findQuote2=0,findSlash=0; //find and locate the ' in a line.
    int countLines=0; //current line number when dealing with the header. count total header lines.
    int countSize =0; //current header size when dealing with the header. count total header size.
    char *strKeywordName;
    char *strKeywordValue;
    char *baLine;    //byte array containing a line.
    int i=0, j=0, headerSize=0, match=-1, valueSize=0, valueQuote1=10, valueQuote2=79, valueTail=0;
    /*initial parameters.*/
    headerSize=strlen(strHeader);
    isHeader=1; countLines=0; countSize=0;
    baLine = (char *)malloc(81*sizeof(char));
    strKeywordName = (char *)malloc(9*sizeof(char));
    //strKeywordValue = (char *)malloc(72*sizeof(char));
    memset(baLine,0x20,80);
    memset(strKeywordName,0x20,8);
    //memset(strKeywordValue,0x20,71);
    *(baLine+80)='\0';
    *(strKeywordName+8)=0x00;
    //*(strKeywordValue+71)=0x00;
    /*Copy the keyword name.*/
    for(i=0;i<8;i++)
    {
        if(i<strlen(strName))
            *(strKeywordName+i)=*(strName+i);
        else
            *(strKeywordName+i)=0x20;
    }
    /*Copy and trim the new keyword value.*/
    strKeywordValue = strtrim2(strValue);
    valueSize = strlen(strKeywordValue);
    if(valueSize>71) valueSize=71; //check the input outflow. the input value size should be .LE. 71.
    //printf("strlen of the keyvalue is %d \n",valueSize);
    /*Begin loop.*/
    while(isHeader==1)
    {
        /*Read in one line.*/
        for(i=0;i<80;i++)
        {
            *(baLine+i) = *(strHeader+countSize+i);
        }
        countSize +=80;
        countLines++;
        /*Classify this line.*/
        flagKeyword=0;flagENDmark=0;flagComment=0;flagHistory=0;
        if(!isSimpleText(baLine))     isHeader=0;
        else if(*(baLine+8)==0x3D) flagKeyword=1; //"=" ASCII is 0x3D.
        else if(isENDmark(baLine)) flagENDmark=1;
        else if(isComment(baLine)) flagComment=1;
        else if(isHistory(baLine)) flagHistory=1;
        /*deal with different type lines.*/
        if(isHeader==0)
        {
            /*header invalid!*/
            err=62;
        }
        else if(flagKeyword==1)
        {
            /*Compare the keyword name.*/
            match = strncmp(baLine,strKeywordName,8);
            findSlash =locateSlash(baLine,10,79);
            if(match==0)
            {
                //string type? number type?
                findQuote1=locateQuote(baLine,9,79);
                /*string type. (contains a pair of quote.)*/
                if(findQuote1>=9 && findQuote1<=11)  //TODO: test the position of ' . Is it always 10?
                {
                    flagStringKeyword=1;
                    findQuote2=locateQuote(baLine,findQuote1+1,79);
                    findSlash =locateSlash(baLine,findQuote2+1,79); //if not found, it is -1.
                    //new value string begins @valueQuote1 and ends @valueQuote2, including the pair of ' '.
                    valueQuote1=findQuote1;
                    valueQuote2=findQuote1+valueSize+1;
                    //AABBCCDD= '1234566777889' / xxxxxxxxx
                    //          '------------>' / xxxxxxxxx (recording range.)
                    //AABBCCDD= '1234566777889000000019293'
                    //          '------------------------>' (recording range.)
                    //Decide where to write the pair of quotes.
                    if(findSlash>findQuote2 && valueQuote2>(findSlash-2))
                        valueQuote2=(findSlash-2);
                    else if(findSlash<=0 && valueQuote2>79)
                        valueQuote2=79;
                    //To write blank space outside the pair of quotes, we need to decide the outer range
                    //of the KeyValue.
                    if(findSlash>findQuote2)
                        valueTail=findSlash;
                    else
                        valueTail=80;
                    //Write down the pair of quotes.
                    *(strHeader+countSize-80+valueQuote1) = 0x27; //"'"
                    *(strHeader+countSize-80+valueQuote2) = 0x27; //"'"
                    //Write chars in the pair of quotes, and blank spaces outside the quotes.
                    for(i=valueQuote1+1,j=0 ;i<valueTail; i++,j++)
                    {
                        if(i<valueQuote2)
                            *(strHeader+countSize-80+i) = *(strKeywordValue+j);
                        else if(i>valueQuote2)
                            *(strHeader+countSize-80+i) = 0x20;
                    }
                }
                /*number type. (contains no quote.)*/
                else
                {
                    flagNumberKeyword=1;
                    findSlash=locateSlash(baLine,9,79); //it should be 31 or 32.
                    if(findSlash<=0) findSlash=31;
                    for(i=(findSlash-2),j=(valueSize-1); i>=9; i--,j--) //i=8 is the '=' mark.
                    {   //write new value into header.
                        //AABBCCDD=      0.555 / xxxxxxxx
                        //AABBCCDD=    123.555 /
                        //          <--------- (recording range.)
                        if(j>=0)
                            *(strHeader+countSize-80+i) = *(strKeywordValue+j);
                        else
                            *(strHeader+countSize-80+i) = 0x20;
                    }
                }
            }
            else
            {
                //
            }
        }
        else if(flagComment==1)
        {
            //
        }
        else if(flagHistory==1)
        {
            //
        }
        else if(flagENDmark==1)
        {
            //
        }
    }
    /*Clean mem.*/
    free((void *)(baLine));
    free((void *)(strKeywordName));
    //free((void *)(strKeywordValue));
    baLine=NULL;
    strKeywordName=NULL;
    strKeywordValue=NULL;
    return strHeader;
}



//add a comment keyword line.
char *addComment(char *strComment, char *strHeader)
{
    int err=0;
    int isHeader=0;    //whether this line is simple text (header).
    //int flagNumberKeyword=0; //whether this line is a number type keyword line.
    //int flagStringKeyword=0; //whether this line is a string type keyword line.
    int flagKeyword=0; //whether this line is a keyword line.
    int flagComment=0; //whether this line is a comment line.
    int flagHistory=0; //whether this line is a history line.
    int flagENDmark=0; //whether this line is a END marked line.
    //int flagEndline=0; //whether this line is the end line of the entire header.
    //int flagQuoted=0;  //whether these chars are quoted by ' '.
    int findLastNonblank=0;//find and locate the last nonblank line.
    //int findLastKeyword=0;//find and locate the last keyword line.
    int findLastComment=0;//find and locate the last comment line.
    //int findLastHistory=0;//find and locate the last history line.
    int findENDmark=0;    //find and locate the END marked line.
    //int findEndline=0;    //find and locate the end line of the entire header.
    //int findQuote1=0,findQuote2=0,findSlash=0; //find and locate the ' in a line.
    int countLines=0; //current line number when dealing with the header. count total header lines.
    int countSize =0; //current header size when dealing with the header. count total header size.
    //char *strKeywordName;
    //char *strKeywordValue;
    char *baLine;    //byte array containing a line.
    //int locateQuote();
    //int locateSlash();
    int i=0,j=0,j1=0,j2=0,i8=0,k=0, headerSize=0;
    int newCommentLines=0, newCommentSize=0, newHeaderSize=0, newBlankLines=0;
    char *newHeader;
    /*initial parameters.*/
    headerSize=strlen(strHeader);
    isHeader=1; countLines=0; countSize=0;
    baLine = (char *)malloc(81*sizeof(char));
    //strKeywordName = (char *)malloc(9*sizeof(char));
    //strKeywordValue = (char *)malloc(72*sizeof(char));
    memset(baLine,0x20,80);
    //memset(strKeywordName,0x20,8);
    //memset(strKeywordValue,0x20,71);
    *(baLine+80)='\0';
    //*(strKeywordName+8)=0x00;
    //*(strKeywordValue+71)=0x00;
    /*Begin loop.*/
    while(isHeader==1)
    {
        /*Read in one line.*/
        for(i=0;i<80;i++)
        {
            *(baLine+i) = *(strHeader+countSize+i);
        }
        countSize += 80;
        countLines++;
        /*Classify this line.*/
        flagKeyword=0;flagENDmark=0;flagComment=0;flagHistory=0;
        if(!isSimpleText(baLine))     isHeader=0;
        else if(*(baLine+8)==0x3D) flagKeyword=1; //"=" ASCII is 0x3D.
        else if(isENDmark(baLine)) flagENDmark=1;
        else if(isComment(baLine)) flagComment=1;
        else if(isHistory(baLine)) flagHistory=1;
        /*deal with different type lines.*/
        if(isHeader==0)
        {
            /*header invalid!*/
            //err=62;
        }
        else if(flagKeyword==1)
        {
            findLastNonblank=countLines-1;
        }
        else if(flagComment==1)
        {
            findLastComment=countLines-1; //starts from 0. 0 means line 1.
            findLastNonblank=countLines-1;
        }
        else if(flagHistory==1)
        {
            findLastNonblank=countLines-1;
        }
        else if(flagENDmark==1)
        {
            findENDmark=countLines-1;
        }
    }
    /*If no comment line found, than use the last line.*/
    if(findLastComment<=1)
    {
        findLastComment=findLastNonblank;
    }
    /*Insert new comment lines.*/
    newCommentSize = strlen(strComment);
    newCommentLines = newCommentSize/72;        //80-8=72
    if(newCommentSize%72!=0) newCommentLines+=1;
    //Fill more blank spaces to make sure the header lines are the integer times of 36.
    //According to IRAF, header size should be the integer times of 2880=36*80.
    if((findENDmark-findLastNonblank-1) >= (newCommentLines%36)) //there are enough blank lines to be removed.
        newBlankLines = -newCommentLines%36;
    else                                //there is no enough blank lines, thus we must add more blank lines.
        newBlankLines = 36 - newCommentLines%36;
    //calculate the newheadersize.
    newHeaderSize = (headerSize+newCommentLines*80+newBlankLines*80+1);
    newHeader = (char *)malloc(newHeaderSize*sizeof(char));
    memset(newHeader,0x20,newHeaderSize-1);
    *(newHeader+newHeaderSize-1)='\0';
    j1 = (findLastComment+1)*80; //the total bytes from 0 to the end of last comment line.
    for(i=0; i<j1; i++)
    {
        *(newHeader+i) = *(strHeader+i);
    }
    j2 = j1 + newCommentLines*80; //the total bytes from 0 to the end of new comment line.
    //insert the new comment after the old lastest comment line. The new comment may occupy multiple lines.
    j=0;
    for(k=0;k<newCommentLines;k++)  //insert new comment line by line.
    {
        i8=j1+k*80;
        *(newHeader+i8+0)='C';*(newHeader+i8+1)='O';*(newHeader+i8+2)='M';*(newHeader+i8+3)='M';
        *(newHeader+i8+4)='E';*(newHeader+i8+5)='N';*(newHeader+i8+6)='T';*(newHeader+i8+7)=' ';
        for(i=8; i<80; i++)
        {
            if(j<newCommentSize)
                *(newHeader+i8+i) = *(strComment+j);
            else
                *(newHeader+i8+i) = 0x20;
            j++;
        }
    }//after loop, i = (j1+(newCommentLines-1)*80+80) == j2. Thus next part will begin from i=j2.
    //copy the remaining part before the END mark.
    for(i=j2,j=j1; j<findENDmark*80; i++,j++)
    {
        *(newHeader+i) = *(strHeader+j);
    }
    j1=j; //j1=findENDmark;
    j2=i; //j2=(findLastComment+1)*80 + newCommentLines*80 + (findENDmark-findLastComment-1)*80;
    //Leave more blank spaces, or remove some blank lines,
    //           to make the header size to be integer times of 2880.
    j2 += newBlankLines*80;
    //copy the last 2880 bytes END part.
    for(i=j2,j=j1; j<headerSize; i++,j++)
    {
        *(newHeader+i) = *(strHeader+j);
    }

    /*Clean mem.*/
    free((void *)strHeader);
    free((void *)(baLine));
    //free((void *)(strKeywordName));
    //free((void *)(strKeywordValue));
    strHeader=NULL;
    baLine=NULL;
    //strKeywordName=NULL;
    //strKeywordValue=NULL;
    err = 0;
    return newHeader;
}



//add a history keyword line.
char *addHistory(char *strHistory, char *strHeader)
{
    int err=0;
    int isHeader=0;    //whether this line is simple text (header).
    //int flagNumberKeyword=0; //whether this line is a number type keyword line.
    //int flagStringKeyword=0; //whether this line is a string type keyword line.
    int flagKeyword=0; //whether this line is a keyword line.
    int flagComment=0; //whether this line is a comment line.
    int flagHistory=0; //whether this line is a history line.
    int flagENDmark=0; //whether this line is a END marked line.
    //int flagEndline=0; //whether this line is the end line of the entire header.
    //int flagQuoted=0;  //whether these chars are quoted by ' '.
    int findLastNonblank=0;//find and locate the last nonblank line.
    //int findLastKeyword=0;//find and locate the last keyword line.
    //int findLastComment=0;//find and locate the last comment line.
    int findLastHistory=0;//find and locate the last history line.
    int findENDmark=0;    //find and locate the END marked line.
    //int findEndline=0;    //find and locate the end line of the entire header.
    //int findQuote1=0,findQuote2=0,findSlash=0; //find and locate the ' in a line.
    int countLines=0; //current line number when dealing with the header. count total header lines.
    int countSize =0; //current header size when dealing with the header. count total header size.
    //char *strKeywordName;
    //char *strKeywordValue;
    char *baLine;    //byte array containing a line.
    //int locateQuote();
    //int locateSlash();
    int i=0,j=0,j1=0,j2=0,i8=0,k=0, headerSize=0;
    //int newCommentLines=0, newCommentSize=0, newHeaderSize=0, newBlankLines=0;
    int newHistoryLines=0, newHistorySize=0, newHeaderSize=0, newBlankLines=0;
    char *newHeader;
    /*initial parameters.*/
    headerSize=strlen(strHeader);
    isHeader=1; countLines=0; countSize=0;
    baLine = (char *)malloc(81*sizeof(char));
    //strKeywordName = (char *)malloc(9*sizeof(char));
    //strKeywordValue = (char *)malloc(72*sizeof(char));
    memset(baLine,0x20,80);
    //memset(strKeywordName,0x20,8);
    //memset(strKeywordValue,0x20,71);
    *(baLine+80)='\0';
    //*(strKeywordName+8)=0x00;
    //*(strKeywordValue+71)=0x00;
    /*Begin loop.*/
    while(isHeader==1)
    {
        /*Read in one line.*/
        for(i=0;i<80;i++)
        {
            *(baLine+i) = *(strHeader+countSize+i);
        }
        countSize += 80;
        countLines++;
        /*Classify this line.*/
        flagKeyword=0;flagENDmark=0;flagComment=0;flagHistory=0;
        if(!isSimpleText(baLine))     isHeader=0;
        else if(*(baLine+8)==0x3D) flagKeyword=1; //"=" ASCII is 0x3D.
        else if(isENDmark(baLine)) flagENDmark=1;
        else if(isComment(baLine)) flagComment=1;
        else if(isHistory(baLine)) flagHistory=1;
        /*deal with different type lines.*/
        if(isHeader==0)
        {
            /*header invalid!*/
            //err=62;
        }
        else if(flagKeyword==1)
        {
            findLastNonblank=countLines-1;
        }
        else if(flagComment==1)
        {
            findLastNonblank=countLines-1;
        }
        else if(flagHistory==1)
        {
            findLastHistory=countLines-1; //starts from 0. 0 means line 1.
            findLastNonblank=countLines-1;
        }
        else if(flagENDmark==1)
        {
            findENDmark=countLines-1;
        }
    }
    /*If no history line found, than use the last line.*/
    if(findLastHistory<=1)
    {
        findLastHistory=findLastNonblank;
    }
    /*Insert new History lines.*/
    newHistorySize = strlen(strHistory);
    newHistoryLines = newHistorySize/72;        //80-8=72
    if(newHistorySize%72!=0) newHistoryLines+=1;
    //Fill more blank spaces to make sure the header lines are the integer times of 36.
    //According to IRAF, header size should be the integer times of 2880=36*80.
    if((findENDmark-findLastNonblank-1) >= (newHistoryLines%36)) //there are enough blank lines to be removed.
        newBlankLines = -newHistoryLines%36;
    else                                //there is no enough blank lines, thus we must add more blank lines.
        newBlankLines = 36 - newHistoryLines%36;
    //calculate the newheadersize.
    newHeaderSize = (headerSize+newHistoryLines*80+newBlankLines*80+1);
    newHeader = (char *)malloc(newHeaderSize*sizeof(char));
    memset(newHeader,0x20,newHeaderSize-1);
    *(newHeader+newHeaderSize-1)='\0';
    j1 = (findLastHistory+1)*80; //the total bytes from 0 to the end of last History line.
    for(i=0; i<j1; i++)
    {
        *(newHeader+i) = *(strHeader+i);
    }
    j2 = j1 + newHistoryLines*80; //the total bytes from 0 to the end of new History line.
    //insert the new History after the old lastest History line. The new History may occupy multiple lines.
    j=0;
    for(k=0;k<newHistoryLines;k++)  //insert new History line by line.
    {
        i8=j1+k*80;
        *(newHeader+i8+0)='H';*(newHeader+i8+1)='I';*(newHeader+i8+2)='S';*(newHeader+i8+3)='T';
        *(newHeader+i8+4)='O';*(newHeader+i8+5)='R';*(newHeader+i8+6)='Y';*(newHeader+i8+7)=' ';
        for(i=8; i<80; i++)
        {
            if(j<newHistorySize)
                *(newHeader+i8+i) = *(strHistory+j);
            else
                *(newHeader+i8+i) = 0x20;
            j++;
        }
    }//after loop, i = (j1+(newHistoryLines-1)*80+80) == j2. Thus next part will begin from i=j2.
    //copy the remaining part before the END mark.
    for(i=j2,j=j1; j<findENDmark*80; i++,j++)
    {
        *(newHeader+i) = *(strHeader+j);
    }
    j1=j; //j1=findENDmark;
    j2=i; //j2=(findLastHistory+1)*80 + newHistoryLines*80 + (findENDmark-findLastHistory-1)*80;
    //Leave more blank spaces, or remove some blank lines,
    //           to make the header size to be integer times of 2880.
    j2 += newBlankLines*80;
    //copy the last 2880 bytes END part.
    for(i=j2,j=j1; j<headerSize; i++,j++)
    {
        *(newHeader+i) = *(strHeader+j);
    }

    /*Clean mem.*/
    free((void *)strHeader);
    free((void *)(baLine));
    //free((void *)(strKeywordName));
    //free((void *)(strKeywordValue));
    strHeader=NULL;
    baLine=NULL;
    //strKeywordName=NULL;
    //strKeywordValue=NULL;
    err = 0;
    return newHeader;
}





int isENDmark(char *baLine)
{
    int is=1;
    is=strncmp(baLine,"END     ",8);
    return !is;
}

int isComment(char *baLine)
{
    int is=1;
    is=strncmp(baLine,"COMMENT ",8);
    return !is;
}

int isHistory(char *baLine)
{
    int is=1;
    is=strncmp(baLine,"HISTORY ",8);
    return !is;
}

int isSimpleText(char *str8)
{
    int isText=1,nsize=0,i=0,j=0;
    char char8; //unsigned char? signed char?
    nsize = strlen(str8);
    isText=1;
    if(nsize==0) isText=0;
    for(i=0;i<nsize;i++)
    {
        char8=*(str8+i);
        j=(int)(char8);
        if(j<=31 || j>=127) isText=0;
    }
    return isText;  //1 for yes, 0 for no.
}

int locateQuote(char *baLine, int nStart, int nEnd)
{   //find the first postion of the quote "'".
    int i=0,find=-1;
    i=nStart;
    if(nStart>nEnd) return -3;
    if(nStart<0 || nEnd>79) return -2;
    while(find==-1 && i<=nEnd)
    {
        if(*(baLine+i)==0x27) find=i; //"'" ASCII is 0x27.
        i++;
    }
    return find;
}

int locateSlash(char *baLine, int nStart, int nEnd)
{   //find the first postion of the slash "/". It should be 31.
    int i=0,find=-1;
    i=nStart;
    if(nStart>nEnd) return -3;
    if(nStart<0 || nEnd>79) return -2;
    while(find==-1 && i<=nEnd)
    {
        if(*(baLine+i)==0x2F) find=i; //"/" ASCII is 0x2F.
        i++;
    }
    return find;
}

char *strtrim2(char *str)
{
    char *head = str;
    char *tail = str + strlen(str); //tail now point to the end mark of a string '\0'.
    while(*head==' ')
    {
        head++;
    }
    tail--;
    while(*tail==' ')
    {
        *tail = '\0';
        tail--;
    }
    return head;
}
