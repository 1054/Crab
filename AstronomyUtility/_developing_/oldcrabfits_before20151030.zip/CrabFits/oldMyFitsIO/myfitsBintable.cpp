#include "myfitsBintable.h"
#include <stdio.h>
#include <string.h>
#include <malloc.h>

void *bintableSelectColumn(void *DataArray, int DataXSize, int DataYSize, char *DataFormat, int Column)
{//DataFormat like "1D,1D,1D,1J," . Column starts from 0
    int ColumnCount=0;
    int i=0;
    int ok=0;
    if(DataYSize<=0)
        return NULL;
    char *DataFormatList = NULL;
    DataFormatList = (char *)malloc(16*sizeof(char));
    memset(DataFormatList,0x0,10);
    int   DataSizeList[16];
    for(i=0;i<16;i++) DataSizeList[i]=0;
    char *DataFormatStr=NULL;
    //make a copy of input DataFormat.
    char *DataFormatCopy = NULL;
    DataFormatCopy = (char *)malloc((strlen(DataFormat)+1)*sizeof(char));
    memset(DataFormatCopy,0x0,(strlen(DataFormat)+1));
    strncpy(DataFormatCopy,(const char *)DataFormat,strlen(DataFormat));
    DataFormatStr = strtok(DataFormatCopy,",");
    char *TempNumb = NULL;
    TempNumb = (char *)malloc(4*sizeof(char)); //max "999D"
    memset(TempNumb,0x0,4);
    char  TempChar = DataFormatStr[1];
    ColumnCount=0;
    //convert from "1D,1D,1D,1J" to "DDDJ" and (8,8,8,4)
    while(DataFormatStr)
    {
        i=0;
        while(DataFormatStr[i]>='1' && DataFormatStr[i]<='9')
        {
            TempNumb[i] = DataFormatStr[i];
            i++;
        }//<TODO: TempNumb itoa then repeat D or J.>
        TempChar = DataFormatStr[i];
        ok=1;
        if('D'==TempChar || 'd'==TempChar)
        {
            DataFormatList[ColumnCount]='D';//double
            DataSizeList[ColumnCount]=8;
        }
        else if('J'==TempChar || 'j'==TempChar)
        {
            DataFormatList[ColumnCount]='J';//int
            DataSizeList[ColumnCount]=4;
        }
        else if('F'==TempChar || 'f'==TempChar)
        {
            DataFormatList[ColumnCount]='F';//float
            DataSizeList[ColumnCount]=4;
        }
        else
            ok=0;
        if(1==ok)
            ColumnCount++;
        DataFormatStr = strtok(NULL,",");
    }
    if(ColumnCount<=0 || Column>=ColumnCount)
        return NULL;

    //select input column.
    int TempSkipSize=0;
    int TempReadSize=0;
    for(i=0;i<Column;i++)
        TempSkipSize+=DataSizeList[i];
    TempReadSize=DataSizeList[i];
    if(TempReadSize<=0)
        return NULL;
    //check total column size.
    int TempTotalSize=0;
    for(i=0;i<ColumnCount;i++)
        TempTotalSize+=DataSizeList[i];
    if(TempTotalSize!=DataXSize)
        return NULL;
    //prepare output void * data.
    char *TempDataOutput = NULL;
    TempDataOutput = (char *)malloc(DataYSize*TempReadSize*sizeof(char));
    memset(TempDataOutput,0x0,DataYSize*TempReadSize);
    char *TempOutputPtr = TempDataOutput;
    int TempLittleEndian = bintableIsLittleEndian();
    char *TempInputPtr = (char *)DataArray+TempSkipSize;
    int  j=0;
    for(i=0; i<DataYSize; i++)
    {
        if(TempLittleEndian)
        {
            for(j=0; j<TempReadSize; j++)//inverse bytes under little endian machine.
                TempOutputPtr[j]=TempInputPtr[TempReadSize-1-j];
        }
        else
        {
            for(j=0; j<TempReadSize; j++)
                TempOutputPtr[j]=TempInputPtr[j];
        }
        TempInputPtr+=TempTotalSize;
        TempOutputPtr+=TempReadSize;
    }
    //output data.
    return (void *)TempDataOutput;
}
void bintableStrtrim(char *str)
{
    if(!str)
        return;
    //trim blank space at begin
    unsigned int k=0;
    while(0x20==str[0])
    {
        k = 0;
        while(k < strlen(str)-1)
        {
            str[k]=str[k+1];
            k++;
        }
        str[k]=0x0;
    }
    //trim blank space at end
    k = strlen(str)-1;
    while(0x20==str[k])
    {
        str[k--]=0x0;
    }
}
int bintableIsLittleEndian()
{
    int isLittleEndian=1;
    /*decide the system's endian.*/
    union{short s; char c[2];}decideEndian;

    //TODO: what if sizeof(short) != 2 ??
    if(sizeof(short) == 2)
    {
        decideEndian.s = 0x0102;
        if(decideEndian.c[0] == 1 && decideEndian.c[1] == 2) //big enidan
            isLittleEndian=0;
        else if(decideEndian.c[0] == 2 && decideEndian.c[1] == 1) //little endian
            isLittleEndian=1;
    }
    return isLittleEndian;
}
