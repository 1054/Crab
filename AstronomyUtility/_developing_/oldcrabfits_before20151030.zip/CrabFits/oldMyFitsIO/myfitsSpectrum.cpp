#include "myfitsSpectrum.h"
#include <stdio.h>
#include <string.h>
#include <malloc.h>
