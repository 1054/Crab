//Usage:
//
//    float *DataArray;
//    DataArray = readFitsImageF("c:\\liudz\\1.fits", 998, 1006, 2880);
//    
//
#include <stdio.h>
#include <malloc.h>
#include <wchar.h>
#include "myfitsio.h"


//float *readFitsImageF(const char *chrFilePath, int ImageWidth, int ImageHeight, int HeaderSize);
//double *readFitsImageF2D(const char *chrFilePath, int ImageWidth, int ImageHeight, int HeaderSize);
//float *readFitsImageD2F(const char *chrFilePath, int ImageWidth, int ImageHeight, int HeaderSize);
//double *readFitsImageD(const char *chrFilePath, int ImageWidth, int ImageHeight, int HeaderSize);
//int isLittleEndian2();


float *readFitsImageF(const char *chrFilePath, int ImageWidth, int ImageHeight, int HeaderSize)
{
    int   err=0;
    int   DataBits=-32;
    float f4 = 0.0;
    char *f4p=NULL;//a char * pointer to f4.
    int   f4i = 0;
    int   i4 = 0;
    char *i4p=NULL;//a char * pointer to i4.
    int   i4i = 0;
    int   nnX=0, nnY=0, nnN=0, nshift=0;
    int   i=0,j=0,m=0;
    float *dataArray4=NULL;
    FILE *fp;
    /*load parameters.*/
    nnX = ImageWidth;
    nnY = ImageHeight;
    nnN = nnX * nnY;
    dataArray4 = (float *)malloc(nnN*sizeof(float));
    if(dataArray4==NULL)
    {
        err = -2;  //mem not enough.
        return NULL;
    }

    /*Open the file.*/
    fp = fopen(chrFilePath,"rb");
    if(fp==NULL)
    {
        /*"Cannot open the file for reading image data!"*/
        err = 5;
        return NULL;
    }
    /*skip the header and prepare for reading image data.*/
    nshift = HeaderSize;
    fseek(fp,nshift,SEEK_SET);
    i=0;j=0;m=0l;
    /*decide the type of the fits data. -32 for 32bits float, 32 for 32bits integer.*/
    if(DataBits==-32)
    {
        for(m=0; m<nnN; m++)
        {
            /*read 4 bytes (32bits) float as a pixel value.*/
            if(isLittleEndian2()) //swap reading bytes order on Intel PC.
            {
                f4p = (char *)&f4;
                f4i = fread(&f4p[3], 1, 1, fp);
                f4i = fread(&f4p[2], 1, 1, fp);
                f4i = fread(&f4p[1], 1, 1, fp);
                f4i = fread(&f4p[0], 1, 1, fp);
            }
            else
            {
                f4i = fread(&f4, 4, 1, fp);
            }
            dataArray4[m]=f4;
        }
    }
    else if(DataBits==32) //32bits integer.  TODO: NOT TESTED YET!
    {
        for(m=0; m<nnN; m++)
        {
            /*read 4 bytes (32bits) float as a pixel value.*/
            if(isLittleEndian2()) //swap reading bytes order on Intel PC.
            {
                i4p = (char *)&f4;
                i4i = fread(&i4p[3], 1, 1, fp);
                i4i = fread(&i4p[2], 1, 1, fp);
                i4i = fread(&i4p[1], 1, 1, fp);
                i4i = fread(&i4p[0], 1, 1, fp);
            }
            else
            {
                i4i = fread(&i4, 4, 1, fp);
            }
            dataArray4[m]=i4;
        }
    }
    else
    {
        return NULL;
    }
    return dataArray4;
}

//read a float type (nbits=-32) FITS into a double array.
double *readFitsImageF2D(const char *chrFilePath, int ImageWidth, int ImageHeight, int HeaderSize)
{
    int   err=0;
    int   DataBits=-32;
    float f4 = 0.0;
    char *f4p=NULL;//a char * pointer to f4.
    int   f4i = 0;
    int   i4 = 0;
    char *i4p=NULL;//a char * pointer to i4.
    int   i4i = 0;
    int   nnX=0, nnY=0, nnN=0, nshift=0;
    int   i=0,j=0,m=0;
    double *dataArray4=NULL;
    FILE *fp;
    /*load parameters.*/
    nnX = ImageWidth;
    nnY = ImageHeight;
    nnN = nnX * nnY;
    dataArray4 = (double *)malloc(nnN*sizeof(double));
    if(dataArray4==NULL)
    {
        err = -2;  //mem not enough.
        return NULL;
    }

    /*Open the file.*/
    fp = fopen(chrFilePath,"rb");
    if(fp==NULL)
    {
        /*"Cannot open the file for reading image data!"*/
        err = 5;
        return NULL;
    }
    /*skip the header and prepare for reading image data.*/
    nshift = HeaderSize;
    fseek(fp,nshift,SEEK_SET);
    i=0;j=0;m=0l;
    /*decide the type of the fits data. -32 for 32bits float, 32 for 32bits integer.*/
    if(DataBits==-32)
    {
        for(m=0; m<nnN; m++)
        {
            /*read 4 bytes (32bits) float as a pixel value.*/
            if(isLittleEndian2()) //swap reading bytes order on Intel PC.
            {
                f4p = (char *)&f4;
                f4i = fread(&f4p[3], 1, 1, fp);
                f4i = fread(&f4p[2], 1, 1, fp);
                f4i = fread(&f4p[1], 1, 1, fp);
                f4i = fread(&f4p[0], 1, 1, fp);
            }
            else
            {
                f4i = fread(&f4, 4, 1, fp);
            }
            dataArray4[m]=(double)f4;
        }
    }
    else if(DataBits==32) //32bits integer.  TODO: NOT TESTED YET!
    {
        for(m=0; m<nnN; m++)
        {
            /*read 4 bytes (32bits) float as a pixel value.*/
            if(isLittleEndian2()) //swap reading bytes order on Intel PC.
            {
                i4p = (char *)&f4;
                i4i = fread(&i4p[3], 1, 1, fp);
                i4i = fread(&i4p[2], 1, 1, fp);
                i4i = fread(&i4p[1], 1, 1, fp);
                i4i = fread(&i4p[0], 1, 1, fp);
            }
            else
            {
                i4i = fread(&i4, 4, 1, fp);
            }
            dataArray4[m]=(double)i4;
        }
    }
    else
    {
        return NULL;
    }
    return dataArray4;
}


float *readFitsImageD2F(const char *chrFilePath, int ImageWidth, int ImageHeight, int HeaderSize)
{
    int   err=0;
    int   DataBits=-64;
    double d4 = 0.0;
    char *d4p=NULL;//a char * pointer to f4.
    int   d4i = 0;
    int   nnX=0, nnY=0, nnN=0, nshift=0;
    int   i=0,j=0,m=0;
    float *dataArray4=NULL;
    FILE *fp;
    /*load parameters.*/
    nnX = ImageWidth;
    nnY = ImageHeight;
    nnN = nnX * nnY;
    dataArray4 = (float *)malloc(nnN*sizeof(float));
    if(dataArray4==NULL)
    {
        err = -2;  //mem not enough.
        return NULL;
    }

    /*Open the file.*/
    fp = fopen(chrFilePath,"rb");
    if(fp==NULL)
    {
        /*"Cannot open the file for reading image data!"*/
        err = 5;
        return NULL;
    }
    /*skip the header and prepare for reading image data.*/
    nshift = HeaderSize;
    fseek(fp,nshift,SEEK_SET);
    i=0;j=0;m=0l;
    /*decide the type of the fits data. -32 for 32bits float, 32 for 32bits integer.*/
    if(DataBits==-64)
    {
        for(m=0; m<nnN; m++)
        {
            /*read 4 bytes (32bits) float as a pixel value.*/
            if(isLittleEndian2()) //swap reading bytes order on Intel PC.
            {
                d4p = (char *)&d4;
                d4i = fread(&d4p[7], 1, 1, fp);
                d4i = fread(&d4p[6], 1, 1, fp);
                d4i = fread(&d4p[5], 1, 1, fp);
                d4i = fread(&d4p[4], 1, 1, fp);
                d4i = fread(&d4p[3], 1, 1, fp);
                d4i = fread(&d4p[2], 1, 1, fp);
                d4i = fread(&d4p[1], 1, 1, fp);
                d4i = fread(&d4p[0], 1, 1, fp);
            }
            else
            {
                d4i = fread(&d4, 4, 1, fp);
            }
            dataArray4[m]=(float)d4;
        }
    }
    else if(DataBits==64) //32bits integer.  TODO: NOT TESTED YET!
    {
        //
    }
    else
    {
        return NULL;
    }
    return dataArray4;
}


double *readFitsImageD(const char *chrFilePath, int ImageWidth, int ImageHeight, int HeaderSize)
{
    int   err=0;
    int   DataBits=-64;
    double d4 = 0.0;
    char *d4p=NULL;//a char * pointer to f4.
    int   d4i = 0;
    int   nnX=0, nnY=0, nnN=0, nshift=0;
    int   i=0,j=0,m=0;
    double *dataArray4=NULL;
    FILE *fp;
    /*load parameters.*/
    nnX = ImageWidth;
    nnY = ImageHeight;
    nnN = nnX * nnY;
    dataArray4 = (double *)malloc(nnN*sizeof(double));
    if(dataArray4==NULL)
    {
        err = -2;  //mem not enough.
        return NULL;
    }

    /*Open the file.*/
    fp = fopen(chrFilePath,"rb");
    if(fp==NULL)
    {
        /*"Cannot open the file for reading image data!"*/
        err = 5;
        return NULL;
    }
    /*skip the header and prepare for reading image data.*/
    nshift = HeaderSize;
    fseek(fp,nshift,SEEK_SET);
    i=0;j=0;m=0l;
    /*decide the type of the fits data. -32 for 32bits float, 32 for 32bits integer.*/
    if(DataBits==-64)
    {
        for(m=0; m<nnN; m++)
        {
            /*read 4 bytes (32bits) float as a pixel value.*/
            if(isLittleEndian2()) //swap reading bytes order on Intel PC.
            {
                d4p = (char *)&d4;
                d4i = fread(&d4p[7], 1, 1, fp);
                d4i = fread(&d4p[6], 1, 1, fp);
                d4i = fread(&d4p[5], 1, 1, fp);
                d4i = fread(&d4p[4], 1, 1, fp);
                d4i = fread(&d4p[3], 1, 1, fp);
                d4i = fread(&d4p[2], 1, 1, fp);
                d4i = fread(&d4p[1], 1, 1, fp);
                d4i = fread(&d4p[0], 1, 1, fp);
            }
            else
            {
                d4i = fread(&d4, 4, 1, fp);
            }
            dataArray4[m]=d4;
        }
    }
    else if(DataBits==64) //32bits integer.  TODO: NOT TESTED YET!
    {
        //
    }
    else
    {
        /*close the file.*/
        fclose(fp);
        return NULL;
    }
    /*close the file.*/
    fclose(fp);
    return dataArray4;

}


int isLittleEndian2() //from "snailsis.c"
{
    int isLittleEndian2=1;

    /*decide the system's endian.*/
    union{short s; char c[2];}decideEndian;

    //TODO: what if sizeof(short) != 2 ??
    if(sizeof(short) == 2)
    {
        decideEndian.s = 0x0102;
        if(decideEndian.c[0] == 1 && decideEndian.c[1] == 2) //big enidan
            isLittleEndian2=0;
        else if(decideEndian.c[0] == 2 && decideEndian.c[1] == 1) //little endian
            isLittleEndian2=1;
    }

    return isLittleEndian2;
}

