//This program aims to deal with fits bintable processing.
#ifndef MYFITSBINTABLE_H
#define MYFITSBINTABLE_H
void *bintableSelectColumn(void *DataArray, int DataXSize, int DataYSize, char *DataFormat, int Column);
void  bintableStrtrim(char *str);
int   bintableIsLittleEndian();
#endif // MYFITSBINTABLE_H
