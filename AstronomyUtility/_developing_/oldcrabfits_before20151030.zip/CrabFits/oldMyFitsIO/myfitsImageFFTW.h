#ifndef myfitsIMAGEFFTW_H
#define myfitsIMAGEFFTW_H
#include "fftw3.h"

/*Fits Image Convolve*/
double *fitsConv64(double *image, double *kernal, int Width, int Height);
double *fitsDeconv64(double *image, double *kernal, int Width, int Height);

/*Image Convolve*/
double *imageConvolve64(double *image1, double *image2, int imageWidth, int imageHeight);

/*Image Fourier Transform 32 bits.*/
fftw_complex *imageFT32(float *img, int imageWidth, int imageHeight);
float *imageIFT32(fftw_complex *imgFT, int imageWidth, int imageHeight);

/*Image Fourier Transform 64 bits.*/
fftw_complex *imageFT64(double *douIMGData, int nnX, int nnY);
double *imageIFT64(fftw_complex *cpxFFTData, int nnX, int nnY);

/*2D FFTW3 Core.*/
fftw_complex *fftw_2d(fftw_complex *in, int nnX, int nnY, int FFTForward);


/*Gaussian Function.*/
double *generateGauss2D(int XSize, int YSize, double HWFM);
double *generateGauss2DArray(double douArrX[3], double douArrY[3], double gauss_A, \
                             double gauss_X0, double gauss_Y0, \
                             double gauss_sigmaX, double gauss_sigmaY);


#endif // myfitsIMAGEFFTW_H
