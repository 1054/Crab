#include "myfitsIO.h"
#include "myfitsBintable.h"
#include <QDebug>
#include <QFile>
#include <QString>

int main(int argc, char *argv[])
{

    char *data = readFitsHeader("E:\\Arp220.fits");


//    char *data = readFitsHeader("E:\\Arp220.fits");
//    qDebug()<<data[0]<<data[1]<<data[2]<<data[3]<<data[4]<<data[5]<<data[6]<<data[7];

//    char *akey = extKeyword("CREATOR",data);
//    qDebug()<<akey;

//    int nnCol=0;
//    int nnRow=0;
//    void *binData = readFitsBintable("E:\\Work\\2011-Master\\Data\\HerschelData\\IC1623_1342212314_spectrum_point_HR_unapod.fits","SSWD4",&nnCol,&nnRow);
//    qDebug() << "nnColumn =" << nnCol << "nnRow =" << nnRow;

//    double *douData = readFitsSpectrum("E:\\Work\\2011-Master\\Data\\HerschelData\\IC1623_1342212314_spectrum_point_HR_unapod.fits","SSWD4");
//    for(int i=0; i<20; i+=2)
//        qDebug()<<douData[i]<<douData[i+1];
    //"E:\\Work\\2011-Master\\Data\\HerschelData\\IC1623_1342212314_spectrum_point_HR_unapod.fits"
    QString strFilePath("E:\\Worm\\Qt_projects1\\d_specViewer\\specViewer\\IC1623_1342212314_spectrum_point_HR_unapod.fits");
    int     xyleng = readFitsSpectrumRows(strFilePath.toLocal8Bit().data(),"SSWD4");
    qDebug()<<"xyleng"<<xyleng;
    double *xydata = readFitsSpectrum(strFilePath.toLocal8Bit().data(),"SSWD4");
    qDebug()<<"xydata"<<xydata[0]<<xydata[1];

//    double *bincolumn0 = NULL;
//    double *bincolumn1 = NULL;
//    double *bincolumn2 = NULL;
//    int *bincolumn3 = NULL;
//    char *formater = (char *)"1D,1D,1D,1J";
//    bincolumn0 = (double *)bintableSelectColumn(bindata,nnCol,nnRow,formater,0);
//    printf("%lf\n",bincolumn0[0]);
//    bincolumn1 = (double *)bintableSelectColumn(bindata,nnCol,nnRow,formater,1);
//    printf("%lf\n",bincolumn1[0]);
//    bincolumn2 = (double *)bintableSelectColumn(bindata,nnCol,nnRow,formater,2);
//    printf("%lf\n",bincolumn2[0]);
//    bincolumn3 = (int *)bintableSelectColumn(bindata,nnCol,nnRow,formater,3);
//    printf("%d\n",bincolumn3[0]);

//    qDebug()<<"wave "<<bincolumn0[0]<<bincolumn0[1]<<bincolumn0[2];
//    qDebug()<<"ampl "<<bincolumn1[0]<<bincolumn1[1]<<bincolumn1[2];
//    qDebug()<<"error"<<bincolumn2[0]<<bincolumn2[1]<<bincolumn2[2];

//    QFile TempFile("E:\\IC1623_SSW.dat");
//    TempFile.open(QFile::WriteOnly);
//    for(int i=0; i<nnRow; i++)
//    {
//        QString TempText = QString("%1, %2, %3 \r\n").arg(bincolumn0[i]).arg(bincolumn1[i]).arg(bincolumn2[i]);
//        TempFile.write(TempText.toLocal8Bit());
//    }
//    TempFile.close();

//    double test2 = 0.3586407649472676;
//    char *testPtr2 = (char *)&test2;

//    readFitsImage("E:\\Worm\\Qt_projects1\\d_fitsImager\\fitsImager\\TEST.fits");

    return 0;
}
