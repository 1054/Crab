//Read fits spectrum.
#ifndef MYFITSSPECTRUM_H
#define MYFITSSPECTRUM_H

#endif // MYFITSSPECTRUM_H
