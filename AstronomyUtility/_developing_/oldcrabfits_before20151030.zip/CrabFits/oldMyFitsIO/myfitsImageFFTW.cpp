#include <malloc.h>
#include <math.h>
#include "myfitsImageFFTW.h"
#define pi 3.141592653589793


/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
//fits image convolution
//*  Image and kernal must have the same size.
//*  Kernal is an image of PSF with the center exactly centered in the image, without even -
//   0.5 pixel bias. If the image size is not an odd number, then the PSF center should be -
//   located in a 0.5 pixel position.
double *fitsConv64(double *image, double *kernal, int Width, int Height)
{
    int u=0,v=0,i=0;
    double *res;
    fftw_complex *imgFT;
    fftw_complex *kerFT;
    fftw_complex *resFT;
    int nnX=Width;
    int nnY=Height;
    int nnN=nnX*nnY;
    double corr=1.0;
    double coRe=1.0;
    double coIm=1.0;
    /*malloc*/
    resFT = (fftw_complex *)fftw_malloc(nnN*sizeof(fftw_complex));
    /*execute the FFTW.*/
    imgFT = imageFT64(image,nnX,nnY);
    kerFT = imageFT64(kernal,nnX,nnY);
    /*correct kernal coordinary bias. (details, referring to my note.)*/
    for(v=0;v<nnY;v++)
    {
        for(u=0;u<nnX;u++)
        {
            i = v*nnX+u;
            corr = u + v - u/nnX - v/nnY;
            coRe = kerFT[i][0]*cos(corr) - kerFT[i][1]*sin(corr);
            coIm = kerFT[i][0]*sin(corr) + kerFT[i][1]*cos(corr);
            kerFT[i][0] = coRe;
            kerFT[i][1] = coIm;
        }
    }
    /*calculate convolution in frequency domain.*/
    for(i=0;i<nnN;i++)
    {
        resFT[i][0]=imgFT[i][0]*kerFT[i][0];
        resFT[i][1]=imgFT[i][1]*kerFT[i][1];
    }
    /*execute the inverse FFTW.*/
    res = imageIFT64(resFT,nnX,nnY);
    /*clean*/
    fftw_free(resFT); fftw_free(imgFT); fftw_free(kerFT);
    resFT=NULL; imgFT=NULL; kerFT=NULL;
    return res;
}



/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
//fits image deconvolution
//*  Image and kernal must have the same size.
//*  Kernal is an image of PSF with the center exactly centered in the image, without even -
//   0.5 pixel bias. If the image size is not an odd number, then the PSF center should be -
//   located in a 0.5 pixel position.
double *fitsDeconv64(double *image, double *kernal, int Width, int Height)
{
    int u=0,v=0,i=0;
    double *res;
    fftw_complex *imgFT;
    fftw_complex *kerFT;
    fftw_complex *resFT;
    int nnX=Width;
    int nnY=Height;
    int nnN=nnX*nnY;
    double corr=1.0;
    double coRe=1.0;
    double coIm=1.0;
    /*malloc*/
    resFT = (fftw_complex *)fftw_malloc(nnN*sizeof(fftw_complex));
    /*execute the FFTW.*/
    imgFT = imageFT64(image,nnX,nnY);
    kerFT = imageFT64(kernal,nnX,nnY);
    /*correct kernal coordinary bias. (details, referring to my note.)*/
    for(v=0;v<nnY;v++)
    {
        for(u=0;u<nnX;u++)
        {
            i = v*nnX+u;
            corr = u + v - u/nnX - v/nnY;
            coRe = kerFT[i][0]*cos(corr) - kerFT[i][1]*sin(corr);
            coIm = kerFT[i][0]*sin(corr) + kerFT[i][1]*cos(corr);
            kerFT[i][0] = coRe;
            kerFT[i][1] = coIm;
        }
    }
    /*calculate convolution in frequency domain.*/
    for(i=0;i<nnN;i++)
    {
        resFT[i][0]=imgFT[i][0]/kerFT[i][0];
        resFT[i][1]=imgFT[i][1]/kerFT[i][1];
    }
    /*execute the inverse FFTW.*/
    res = imageIFT64(resFT,nnX,nnY);
    /*clean*/
    fftw_free(resFT); fftw_free(imgFT); fftw_free(kerFT);
    resFT=NULL; imgFT=NULL; kerFT=NULL;
    return res;
}



/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
//image convolve
//*  The two image must have the same size.
//   <TODO>we recommand two image have the same size, otherwise we have to padding the smaller one with 0.
double *imageConv64(double *image1, double *image2, int imageWidth, int imageHeight)
{
    int i=0;
    double *res;
    fftw_complex *imgFT;
    fftw_complex *kerFT;
    fftw_complex *resFT;
    int nnX=imageWidth;
    int nnY=imageHeight;
    int nnN=nnX*nnY;
    /*malloc*/
    resFT = (fftw_complex *)fftw_malloc(nnN*sizeof(fftw_complex));
    /*execute the FFTW.*/
    imgFT = imageFT64(image1,nnX,nnY);
    kerFT = imageFT64(image2,nnX,nnY);
    /*calculate convolution in frequency domain.*/
    for(i=0;i<nnN;i++)
    {
        resFT[i][0]=imgFT[i][0]*kerFT[i][0];
        resFT[i][1]=imgFT[i][1]*kerFT[i][1];
    }
    /*execute the inverse FFTW.*/
    res = imageIFT64(resFT,nnX,nnY);
    /*clean*/
    fftw_free(resFT); fftw_free(imgFT); fftw_free(kerFT);
    resFT=NULL; imgFT=NULL; kerFT=NULL;
    return res;
}



/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
//image deconvolve
//<TODO>



/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
fftw_complex *imageFT32(float *img, int imageWidth, int imageHeight)
{
    int i=0;
    double *imgOId; //OI=Origin
    fftw_complex *imgFT;
    int nnN = imageWidth*imageHeight;
    /*float to double.*/
    imgOId = (double *)malloc(nnN*sizeof(double));
    for(i=0;i<nnN;i++)
        imgOId[i]=(double)img[i];
    /*execute the FFTW.*/
    imgFT = imageFT64(imgOId,imageWidth,imageHeight);
    /*return the FT data.*/
    free((void *)imgOId);
    return imgFT;
}

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
float *imageIFT32(fftw_complex *imgFT, int imageWidth, int imageHeight)
{
    int i=0;
    float *imgOIf;
    double *imgOId;
    int nnN = imageWidth*imageHeight;
    /*execute the FFTW.*/
    imgOId = imageIFT64(imgFT,imageWidth,imageHeight);
    /*double to float*/
    imgOIf = (float *)malloc(nnN*sizeof(float));
    for(i=0;i<nnN;i++)
        imgOIf[i]=(float)imgOId[i];
    /*return the image data.*/
    return imgOIf;
}

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
//Forward Normalized fftw 2Dimension RealDouble2ComplexDouble.
fftw_complex *imageFT64(double *douIMGData, int nnX, int nnY)
{
    int m=0,nnN=0;
    fftw_complex *IMGData;
    fftw_complex *FFTData;
    nnN = nnX*nnY;
    /*malloc array mem.*/
    IMGData = (fftw_complex *)fftw_malloc(nnN*sizeof(fftw_complex));
    if(IMGData==NULL) return NULL;
    /*initial Image's complex array.*/
    for(m=0; m<nnN; m++)
    {
        IMGData[m][0]=douIMGData[m];
        IMGData[m][1]=(double)0.0;
    }
    /*execute the fftw.*/
    FFTData = fftw_2d(IMGData,nnX,nnY,-1); // forward.
    fftw_free(IMGData);
    IMGData=NULL;
    return FFTData;
}

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
//Backward Normalized fftw 2Dimension ComplexDouble2RealDouble.
double *imageIFT64(fftw_complex *cpxFFTData, int nnX, int nnY)
{
    int m=0,nnN=0;
    float dou_Value=0.0;
    fftw_complex *Output;
    double *douIMGData;
    nnN = nnX*nnY;
    /*malloc array mem.*/
    douIMGData = (double *)malloc(nnN*sizeof(double));
    if(douIMGData==NULL) return NULL;
    /*execute the fftw.*/
    Output = fftw_2d(cpxFFTData,nnX,nnY,+1); // backward.
    /*normalize the ifftw result f(x,y).*/
    for(m=0; m<nnN; m++)
    {
        Output[m][0] = Output[m][0]/(double)nnN;
        Output[m][1] = Output[m][1]/(double)nnN;
    }
    /*Convert fftw_complex to real double.*/
    for(m=0; m<nnN; m++)
    { //Amplitude=(re^2+im^2)^(-2)
        dou_Value = sqrt(Output[m][0]*Output[m][0] + Output[m][1]*Output[m][1]);
        douIMGData[m]=dou_Value;
    }
    fftw_free(Output);
    Output=NULL;
    return douIMGData;
}

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
/*CORE*/
fftw_complex *fftw_2d(fftw_complex *in, int nnX, int nnY, int FFTForward)
{
   //fftw_complex *in;
   fftw_complex *out;
   fftw_plan p;
   /*Set fftw *in and *out arrays.*/
   //in  = (fftw_complex *)fftw_malloc(nnX*nnY*sizeof(fftw_complex));
   out = (fftw_complex *)fftw_malloc(nnX*nnY*sizeof(fftw_complex));
   /*Prepare the fftw plan.*/
   if(FFTForward<0)
   {
       p = fftw_plan_dft_2d(nnY, nnX, in, out, FFTW_FORWARD, FFTW_ESTIMATE);
   }
   else
   {
       p = fftw_plan_dft_2d(nnY, nnX, in, out, FFTW_BACKWARD, FFTW_ESTIMATE);
   }
   /*Execute fftw.*/
   fftw_execute(p);    /* repeat as needed */
   /*Clean mem and done.*/
   fftw_destroy_plan(p);
   //fftw_free(in);
   //fftw_free(out);
   return out;
}


/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
//*  This program generate a "double *" type array containing a 2D-gaussian image.
//*  Moreover, we set the peak of the gauss to be x=0.0 and y=0.0, which equals i=intX_center
//   and j=intY_center in the image.
//*  The center of the image doesn't mean the peak of the gauss. Thus the gauss peak can locate
//   at other place than the image center.
//*  Besides, in the program, we always use x=0.0, y=0.0 to calculate the peak, and to make sure
//   that we will slightly shift the input calculation range. e.g. input douArrX={-2.1,2.2,1.0},
//   then we will use a slightly modified {-2.0,2.2,1.0} array as the calculation range.
//   Thus we will calculate the 2D gauss function at x=-2.0,-1.0,0.0,1.0,2.0.
//
//*  The return array is a "double *" type array. Here we use a 1D array (C type, not Fortran),
//   and if you want to use array(i=i,j=j) then you can just use array[j*nnX+i], in which
//   nnX is the number of points of a row(which have the same j value).
//   This is the same with fftw.
//
//Usage:
//   double *output;
//   double douArr1[3]={-498.0,499.0,1.0};  //998
//   double douArr2[3]={-502.0,503.0,1.0};  //1006
//   output = generateGauss2DArray(douArr1,douArr2,1.0,0.0,0.0,15.0,15.0);
//
//simpler way:
//   double *output;
//   output = generateGauss2D(998,1006,20.0);
//Be sure that you have calculated the right HWFM=20.0 according to the beam of the telescope.
//
//
//More:
//   about FWHM and standart deviation (sigma):
//   sigma = fwhm/( 2.0d* sqrt( 2.0d* aLog(2.0d) ) ) = fwhm / 2.3548200
//                                    aLog() is ln()
//   Which is :
//   HWFM = 2.3548200*gauss_sigma
//   Note that HWFM is in unit of PIXELs. (NOT arcsecs!)
//
double *generateGauss2D(int XSize, int YSize, double HWFM)
{
    //generate a normalized gaussian image with pixel interval of 1.0, width of XSize and height of YSize.
    //and it's peak is at center pixel(odd) or 0.5 near it(even).
    //and it has an equal sigma, gauss_sigmaX=gauss_sigmaY.
    //and it is periodic. (like FFT's properities.)
    double douArrX[3];
    double douArrY[3];
    double gauss_A=1.0;
    int    temp1=0;
    int    temp2=0;
    double gauss_X0=0.0;
    double gauss_Y0=0.0;
    double gauss_sigma=0.0;
    if(XSize%2==0)
    {
        temp1=(int)(1-XSize/2);
        temp2=(int)(XSize/2);
        douArrX[0]=(double)temp1;
        douArrX[1]=(double)temp2;
        douArrX[2]=1.0;
    }
    else if(XSize%2!=0)
    {
        temp1=(int)(-(XSize-1)/2);
        temp2=(int)((XSize-1)/2);
        douArrX[0]=(double)temp1;
        douArrX[1]=(double)temp2;
        douArrX[2]=1.0;
    }
    if(YSize%2==0)
    {
        temp1=(int)(1-YSize/2);
        temp2=(int)(YSize/2);
        douArrY[0]=(double)temp1;
        douArrY[1]=(double)temp2;
        douArrY[2]=1.0;
    }
    else if(YSize%2!=0)
    {
        temp1=(int)(-(YSize-1)/2);
        temp2=(int)((YSize-1)/2);
        douArrY[0]=(double)temp1;
        douArrY[1]=(double)temp2;
        douArrY[2]=1.0;
    }
    gauss_sigma = HWFM / 2.3548200;
    gauss_A = gauss_A*gauss_sigma*gauss_sigma*2.0*pi;
                       //normalizing factor, pls referring to the integration of gauss function.
    return generateGauss2DArray(douArrX,douArrY,gauss_A,gauss_X0,gauss_Y0,gauss_sigma,gauss_sigma);
}


/*core function.*/
double *generateGauss2DArray(double douArrX[3], double douArrY[3], double gauss_A, \
                             double gauss_X0, double gauss_Y0, \
                             double gauss_sigmaX, double gauss_sigmaY)
{
   int  i,j;
   long m;
   double douix, doujy;
   double douX_init, douX_final, douX_step;
   double douY_init, douY_final, douY_step;
   int  intX_counts, intY_counts;
   int  nnX, nnY;
   double *douArr;
   double douTmp1, douTmp2, douTmp3, douTmp4, douTmp5, douTmp6;

   double *doubleData;

   /*Calculate parameters.*/
   douX_init = douArrX[0]; douX_final = douArrX[1]; douX_step = douArrX[2];
   douY_init = douArrY[0]; douY_final = douArrY[1]; douY_step = douArrY[2];
   intX_counts = (int)( (douX_final - douX_init)/douX_step + 1 );
   intY_counts = (int)( (douY_final - douY_init)/douY_step + 1 );
   nnX = intX_counts; nnY = intY_counts;

   douArr = (double *)malloc(nnX * nnY * sizeof(double) );
   douTmp5 = 2.0*gauss_sigmaX*gauss_sigmaX;
   douTmp5 = 1.0/douTmp5;
   if(gauss_sigmaY==gauss_sigmaX)
   {
      douTmp6 = douTmp5;
   }
   else
   {
      douTmp6 = 2.0*gauss_sigmaY*gauss_sigmaY;
      douTmp6 = 1.0/douTmp6;
   }

   for(j=0,doujy=douY_init; j<nnY; j++,doujy+=douY_step)
   {
      for(i=0,douix=douX_init; i<nnX; i++,douix+=douX_step)
      {
         //function is : f(x,y) = A*exp(-((x-x0)**2+(y-x0)**2)/(2*gauss_c**2))
         m = (long)j*nnX + i;
         douTmp3 = (douix - gauss_X0)*(douix - gauss_X0)*douTmp5;
         douTmp4 = (doujy - gauss_Y0)*(doujy - gauss_Y0)*douTmp6;
         douTmp2 = 0.0 - douTmp3 - douTmp4;
         douTmp1 = exp(douTmp2);
         douArr[m] = gauss_A * douTmp1;
      }
   }
   doubleData = douArr;
   return doubleData;
}
