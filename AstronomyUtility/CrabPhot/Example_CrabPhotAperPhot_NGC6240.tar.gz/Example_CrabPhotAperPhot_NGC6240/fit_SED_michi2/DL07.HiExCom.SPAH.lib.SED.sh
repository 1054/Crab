#!/bin/bash
# 

# 
# simplified DL07 library with only 2 qPAH values: 1.12 and 2.5. 
# 

grep -E "    1.120000$|    2.500000$|^#" "DL07.HiExCom.lib.SED" > "DL07.HiExCom.SPAH.lib.SED"
# NVAR2 = 44
# NPAR2 = 2

grep -E "    1.120000$|    2.500000$|^#" "DL07.LoExCom.lib.SED" > "DL07.LoExCom.SPAH.lib.SED"
# NVAR2 = 44
# NPAR2 = 2
