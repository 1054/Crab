#!/bin/bash
unzip /home/dzliu/Cloud/SpireLines/Tool/Level_3_SciData/07_SED_Synthesis/02_Make_Lib_SED/DL07.DuoCom.SinglePAH.lib.zip
unzip /home/dzliu/Cloud/SpireLines/Tool/Level_3_SciData/07_SED_Synthesis/02_Make_Lib_SED/FSPS.Padova.BaSeL.Z0.0190.EBV.lib.zip
cp /home/dzliu/Cloud/SpireLines/Tool/Level_3_SciData/07_SED_Synthesis/04_Plot_Best_Chi2/pChisq.sm .
cp /home/dzliu/Cloud/SpireLines/Tool/Level_3_SciData/07_SED_Synthesis/04_Plot_Best_Chi2/rChisq.sm .
cp /home/dzliu/Cloud/SpireLines/Tool/Level_3_SciData/07_SED_Synthesis/04_Plot_Best_Chi2/rShift.sm .
cp /home/dzliu/Cloud/SpireLines/Tool/Level_3_SciData/07_SED_Synthesis/04_Plot_Best_Chi2/rUmean.sm .
sm <<< "macro read rShift.sm redShift_maskout_Radio 0.024480"
chmod +x michi2*
./michi2_v02_201509_DL07 -obs flux_restframe.dat -lib "FSPS.Padova.BaSeL.Z0.0190.EBV.lib.SED" "DL07.HiExCom.SPAH.lib.SED" "DL07.LoExCom.SPAH.lib.SED" -out fit_triple.out
sm << EOF
macro read pChisq.sm plotChisq "flux_obsframe.dat" "FSPS.Padova.BaSeL.Z0.0190.EBV.lib.SED" \
"DL07.HiExCom.SPAH.lib.SED" "DL07.LoExCom.SPAH.lib.SED" "fit_triple.out"
quit
EOF

