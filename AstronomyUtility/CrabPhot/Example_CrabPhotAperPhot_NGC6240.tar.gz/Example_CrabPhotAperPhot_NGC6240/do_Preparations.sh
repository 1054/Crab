#!/bin/bash
#

rm "ListOfPhotos.txt" 2>/dev/null
rm "ListOfWavelengths.txt" 2>/dev/null
rm "ListOfApertures.txt" 2>/dev/null
rm "ListOfApertures.reg" 2>/dev/null
rm "ListOfSkyApertures.txt" 2>/dev/null
rm "ListOfSkyApertures.reg" 2>/dev/null
rm "ListOfPhotoMagZP.txt" 2>/dev/null
rm "ListOfPhotoFluxZP.txt" 2>/dev/null
rm "ListOfPhotoFluxConv.txt" 2>/dev/null

# use DS9 to tune the parameters below

echo $(ls -1 ../../phot/HST_Photo/*_wfpc2_f450w_*.fits)"[1]" >> "ListOfPhotos.txt"
echo $(ls -1 ../../phot/HST_Photo/*_wfpc2_f547m_*.fits)"[1]" >> "ListOfPhotos.txt"
echo $(ls -1 ../../phot/HST_Photo/*_wfpc2_f658n_*.fits)"[1]" >> "ListOfPhotos.txt"
echo $(ls -1 ../../phot/HST_Photo/*_wfpc2_f673n_*.fits)"[1]" >> "ListOfPhotos.txt"
echo $(ls -1 ../../phot/HST_Photo/*_wfpc2_f814w_*.fits)"[1]" >> "ListOfPhotos.txt"
printf "%12g\n" "0.450" >> "ListOfWavelengths.txt"
printf "%12g\n" "0.547" >> "ListOfWavelengths.txt"
printf "%12g\n" "0.658" >> "ListOfWavelengths.txt"
printf "%12g\n" "0.673" >> "ListOfWavelengths.txt"
printf "%12g\n" "0.814" >> "ListOfWavelengths.txt"
printf "%12g\n" "0" >> "ListOfPhotoFluxZP.txt" # 
printf "%12g\n" "0" >> "ListOfPhotoFluxZP.txt" # 
printf "%12g\n" "0" >> "ListOfPhotoFluxZP.txt" # 
printf "%12g\n" "0" >> "ListOfPhotoFluxZP.txt" # 
printf "%12g\n" "0" >> "ListOfPhotoFluxZP.txt" # 
printf "%18s%18s%12g%12g%12g\n"              "16:52:58.955" "+2:24:04.15" "19.0" "16.0" "-60" >> "ListOfApertures.txt" # THIS IS NOT THE CrabPhotAperPhot FORMAT!
printf "%18s%18s%12g%12g%12g\n"              "16:52:58.955" "+2:24:04.15" "19.0" "16.0" "-60" >> "ListOfApertures.txt" # THIS IS NOT THE CrabPhotAperPhot FORMAT!
printf "%18s%18s%12g%12g%12g\n"              "16:52:58.955" "+2:24:04.15" "19.0" "16.0" "-60" >> "ListOfApertures.txt" # THIS IS NOT THE CrabPhotAperPhot FORMAT!
printf "%18s%18s%12g%12g%12g\n"              "16:52:58.955" "+2:24:04.15" "19.0" "16.0" "-60" >> "ListOfApertures.txt" # THIS IS NOT THE CrabPhotAperPhot FORMAT!
printf "%18s%18s%12g%12g%12g\n"              "16:52:58.955" "+2:24:04.15" "19.0" "16.0" "-60" >> "ListOfApertures.txt" # THIS IS NOT THE CrabPhotAperPhot FORMAT!
printf "image;ellipse(%s,%s,%g\",%g\",%g)\n" "16:52:58.955" "+2:24:04.15" "19.0" "16.0" "-60" >> "ListOfApertures.reg" # Major axis, minor axis, angle -60 degree.
printf "image;ellipse(%s,%s,%g\",%g\",%g)\n" "16:52:58.955" "+2:24:04.15" "19.0" "16.0" "-60" >> "ListOfApertures.reg" # Major axis, minor axis, angle -60 degree.
printf "image;ellipse(%s,%s,%g\",%g\",%g)\n" "16:52:58.955" "+2:24:04.15" "19.0" "16.0" "-60" >> "ListOfApertures.reg" # Major axis, minor axis, angle -60 degree.
printf "image;ellipse(%s,%s,%g\",%g\",%g)\n" "16:52:58.955" "+2:24:04.15" "19.0" "16.0" "-60" >> "ListOfApertures.reg" # Major axis, minor axis, angle -60 degree.
printf "image;ellipse(%s,%s,%g\",%g\",%g)\n" "16:52:58.955" "+2:24:04.15" "19.0" "16.0" "-60" >> "ListOfApertures.reg" # Major axis, minor axis, angle -60 degree.
printf "%18s%18s%12g%12g%12g\n"              "16:52:56.730" "+2:24:34.57" "19.0" "16.0" "-60" >> "ListOfSkyApertures.txt" # Sky aperture
printf "%18s%18s%12g%12g%12g\n"              "16:52:56.730" "+2:24:34.57" "19.0" "16.0" "-60" >> "ListOfSkyApertures.txt" # Sky aperture
printf "%18s%18s%12g%12g%12g\n"              "16:52:56.730" "+2:24:34.57" "19.0" "16.0" "-60" >> "ListOfSkyApertures.txt" # Sky aperture
printf "%18s%18s%12g%12g%12g\n"              "16:52:56.730" "+2:24:34.57" "19.0" "16.0" "-60" >> "ListOfSkyApertures.txt" # Sky aperture
printf "%18s%18s%12g%12g%12g\n"              "16:52:56.730" "+2:24:34.57" "19.0" "16.0" "-60" >> "ListOfSkyApertures.txt" # Sky aperture
printf "image;ellipse(%s,%s,%g\",%g\",%g)\n" "16:52:56.730" "+2:24:34.57" "19.0" "16.0" "-60" >> "ListOfSkyApertures.reg" # Sky aperture
printf "image;ellipse(%s,%s,%g\",%g\",%g)\n" "16:52:56.730" "+2:24:34.57" "19.0" "16.0" "-60" >> "ListOfSkyApertures.reg" # Sky aperture
printf "image;ellipse(%s,%s,%g\",%g\",%g)\n" "16:52:56.730" "+2:24:34.57" "19.0" "16.0" "-60" >> "ListOfSkyApertures.reg" # Sky aperture
printf "image;ellipse(%s,%s,%g\",%g\",%g)\n" "16:52:56.730" "+2:24:34.57" "19.0" "16.0" "-60" >> "ListOfSkyApertures.reg" # Sky aperture
printf "image;ellipse(%s,%s,%g\",%g\",%g)\n" "16:52:56.730" "+2:24:34.57" "19.0" "16.0" "-60" >> "ListOfSkyApertures.reg" # Sky aperture

ls -1 ../../phot/2MASS_Photo/j*.fits >> "ListOfPhotos.txt"
ls -1 ../../phot/2MASS_Photo/h*.fits >> "ListOfPhotos.txt"
ls -1 ../../phot/2MASS_Photo/k*.fits >> "ListOfPhotos.txt"
printf "%12g\n" "1.25" >> "ListOfWavelengths.txt"
printf "%12g\n" "1.65" >> "ListOfWavelengths.txt"
printf "%12g\n" "2.17" >> "ListOfWavelengths.txt"
printf "%12g\n" "1594.0" >> "ListOfPhotoFluxZP.txt" # 2MASS, J, MAGZP=20.8688, FLUXZP=1594., calc 1594./(10**((0-20.8688)/(-2.5))) # 7.160911675e-06 Jy/DN # # http://www.ipac.caltech.edu/2mass/releases/allsky/faq.html#conversion
printf "%12g\n" "1024.0" >> "ListOfPhotoFluxZP.txt" # 2MASS, H, MAGZP=20.3495, FLUXZP=1024., calc 1024./(10**((0-20.3495)/(-2.5))) # 7.421641236e-06 Jy/DN # # http://www.ipac.caltech.edu/2mass/releases/allsky/faq.html#conversion
printf "%12g\n" "666.7"  >> "ListOfPhotoFluxZP.txt" # 2MASS, K, MAGZP=20.0662, FLUXZP=666.7, calc 666.7/(10**((0-20.0662)/(-2.5))) # 6.272641328e-06 Jy/DN # # http://www.ipac.caltech.edu/2mass/releases/allsky/faq.html#conversion
#printf "%30g\n" "7.160911675e-06" >> "ListOfPhotoFluxConv.txt" # 2MASS, J, MAGZP=20.8688, FLUXZP=1594., calc 1594./(10**((0-20.8688)/(-2.5))) # 7.160911675e-06 Jy/DN # # http://www.ipac.caltech.edu/2mass/releases/allsky/faq.html#conversion
#printf "%30g\n" "7.421641236e-06" >> "ListOfPhotoFluxConv.txt" # 2MASS, H, MAGZP=20.3495, FLUXZP=1024., calc 1024./(10**((0-20.3495)/(-2.5))) # 7.421641236e-06 Jy/DN # # http://www.ipac.caltech.edu/2mass/releases/allsky/faq.html#conversion
#printf "%30g\n" "6.272641328e-06" >> "ListOfPhotoFluxConv.txt" # 2MASS, K, MAGZP=20.0662, FLUXZP=666.7, calc 666.7/(10**((0-20.0662)/(-2.5))) # 6.272641328e-06 Jy/DN # # http://www.ipac.caltech.edu/2mass/releases/allsky/faq.html#conversion
printf "%18s%18s%12g%12g%12g\n"              "16:52:58.955" "+2:24:04.15" "35.0" "20.0" "-60" >> "ListOfApertures.txt" # THIS IS NOT THE CrabPhotAperPhot FORMAT!
printf "%18s%18s%12g%12g%12g\n"              "16:52:58.955" "+2:24:04.15" "35.0" "20.0" "-60" >> "ListOfApertures.txt" # THIS IS NOT THE CrabPhotAperPhot FORMAT!
printf "%18s%18s%12g%12g%12g\n"              "16:52:58.955" "+2:24:04.15" "35.0" "20.0" "-60" >> "ListOfApertures.txt" # THIS IS NOT THE CrabPhotAperPhot FORMAT!
printf "image;ellipse(%s,%s,%g\",%g\",%g)\n" "16:52:58.955" "+2:24:04.15" "35.0" "20.0" "-60" >> "ListOfApertures.reg" # Major axis 35", minor axis 20", angle -60 degree.
printf "image;ellipse(%s,%s,%g\",%g\",%g)\n" "16:52:58.955" "+2:24:04.15" "35.0" "20.0" "-60" >> "ListOfApertures.reg" # Major axis 35", minor axis 20", angle -60 degree.
printf "image;ellipse(%s,%s,%g\",%g\",%g)\n" "16:52:58.955" "+2:24:04.15" "35.0" "20.0" "-60" >> "ListOfApertures.reg" # Major axis 35", minor axis 20", angle -60 degree.
printf "%18s%18s%12g%12g%12g\n"              "16:52:49.402" "+2:26:41.45" "35.0" "20.0" "-60" >> "ListOfSkyApertures.txt" # Sky aperture
printf "%18s%18s%12g%12g%12g\n"              "16:52:49.402" "+2:26:41.45" "35.0" "20.0" "-60" >> "ListOfSkyApertures.txt" # Sky aperture
printf "%18s%18s%12g%12g%12g\n"              "16:52:49.402" "+2:26:41.45" "35.0" "20.0" "-60" >> "ListOfSkyApertures.txt" # Sky aperture
printf "image;ellipse(%s,%s,%g\",%g\",%g)\n" "16:52:49.402" "+2:26:41.45" "35.0" "20.0" "-60" >> "ListOfSkyApertures.reg" # Sky aperture
printf "image;ellipse(%s,%s,%g\",%g\",%g)\n" "16:52:49.402" "+2:26:41.45" "35.0" "20.0" "-60" >> "ListOfSkyApertures.reg" # Sky aperture
printf "image;ellipse(%s,%s,%g\",%g\",%g)\n" "16:52:49.402" "+2:26:41.45" "35.0" "20.0" "-60" >> "ListOfSkyApertures.reg" # Sky aperture
#gethead ../../phot/2MASS_Photo/j*.fits "MAGZP" # different sources have different values!? # 20.8688
#gethead ../../phot/2MASS_Photo/h*.fits "MAGZP" # 20.3495
#gethead ../../phot/2MASS_Photo/k*.fits "MAGZP" # 20.0662



ls -1 ../../phot/WISE_Photo/*-w1-int-*.fits >> "ListOfPhotos.txt"
ls -1 ../../phot/WISE_Photo/*-w2-int-*.fits >> "ListOfPhotos.txt"
ls -1 ../../phot/WISE_Photo/*-w3-int-*.fits >> "ListOfPhotos.txt"
ls -1 ../../phot/WISE_Photo/*-w4-int-*.fits >> "ListOfPhotos.txt"
printf "%12g\n" "3.368"   >> "ListOfWavelengths.txt"
printf "%12g\n" "4.618"   >> "ListOfWavelengths.txt"
printf "%12g\n" "12.082"  >> "ListOfWavelengths.txt"
printf "%12g\n" "22.194"  >> "ListOfWavelengths.txt"
printf "%12g\n" "309.540" >> "ListOfPhotoFluxZP.txt" # WISE, W1, MAGZP=20.5, FLUXZP=309.540, calc 309.540/(10**((0-20.5)/(-2.5))) # Jy/DN # # http://wise2.ipac.caltech.edu/docs/release/allsky/expsup/sec4_4h.html # # http://wise2.ipac.caltech.edu/docs/release/allsky/expsup/sec2_3f.html#coadphot # # https://github.com/keflavich/agpy/blob/master/agpy/WISE_to_MJySr.py
printf "%30g\n" "171.787" >> "ListOfPhotoFluxZP.txt" # WISE, W2, MAGZP=19.5, FLUXZP=171.787, calc 171.787/(10**((0-19.5)/(-2.5))) # Jy/DN # # http://wise2.ipac.caltech.edu/docs/release/allsky/expsup/sec4_4h.html # # http://wise2.ipac.caltech.edu/docs/release/allsky/expsup/sec2_3f.html#coadphot # # https://github.com/keflavich/agpy/blob/master/agpy/WISE_to_MJySr.py
printf "%30g\n" "31.674"  >> "ListOfPhotoFluxZP.txt" # WISE, W3, MAGZP=18.0, FLUXZP=31.674,  calc 31.6740/(10**((0-18.0)/(-2.5))) # Jy/DN # # http://wise2.ipac.caltech.edu/docs/release/allsky/expsup/sec4_4h.html # # http://wise2.ipac.caltech.edu/docs/release/allsky/expsup/sec2_3f.html#coadphot # # https://github.com/keflavich/agpy/blob/master/agpy/WISE_to_MJySr.py
printf "%30g\n" "8.363"   >> "ListOfPhotoFluxZP.txt" # WISE, W4, MAGZP=13.0, FLUXZP=8.363,   calc 8.36300/(10**((0-13.0)/(-2.5))) # Jy/DN # # http://wise2.ipac.caltech.edu/docs/release/allsky/expsup/sec4_4h.html # # http://wise2.ipac.caltech.edu/docs/release/allsky/expsup/sec2_3f.html#coadphot # # https://github.com/keflavich/agpy/blob/master/agpy/WISE_to_MJySr.py
#printf "%12g\n" $(idl -quiet -e "print, double(309.540)*10^(-2.699/2.5)" | sed -e 's/ //g') >> "ListOfPhotoFluxZP.txt" # WISE, W1, MAGZP=20.5-2.699, FLUXZP=309.540, calc 309.540/(10**((2.699-20.5)/(-2.5))) = 309.540*10**(-2.699/2.5)/(10**(20.5/2.5)) # Jy/DN # # http://wise2.ipac.caltech.edu/docs/release/allsky/expsup/sec4_4h.html
#printf "%30g\n" $(idl -quiet -e "print, double(171.787)*10^(-3.339/2.5)" | sed -e 's/ //g') >> "ListOfPhotoFluxZP.txt" # WISE, W2, MAGZP=19.5-3.339, FLUXZP=171.787, calc 171.787/(10**((3.339-19.5)/(-2.5))) = 171.787*10**(-3.339/2.5)/(10**(19.5/2.5)) # Jy/DN # # http://wise2.ipac.caltech.edu/docs/release/allsky/expsup/sec4_4h.html
#printf "%30g\n" $(idl -quiet -e "print, double(31.674)*10^(-5.174/2.5)"  | sed -e 's/ //g') >> "ListOfPhotoFluxZP.txt" # WISE, W3, MAGZP=18.0-5.174, FLUXZP=31.674,  calc 31.6740/(10**((5.174-18.0)/(-2.5))) = 31.6740*10**(-5.174/2.5)/(10**(18.0/2.5)) # Jy/DN # # http://wise2.ipac.caltech.edu/docs/release/allsky/expsup/sec4_4h.html
#printf "%30g\n" $(idl -quiet -e "print, double(8.363)*10^(-6.620/2.5)"   | sed -e 's/ //g') >> "ListOfPhotoFluxZP.txt" # WISE, W4, MAGZP=13.0-6.620, FLUXZP=8.363,   calc 8.36300/(10**((6.620-13.0)/(-2.5))) = 8.36300*10**(-6.620/2.5)/(10**(13.0/2.5)) # Jy/DN # # http://wise2.ipac.caltech.edu/docs/release/allsky/expsup/sec4_4h.html # # http://www.adamgginsburg.com/filtersets.htm
printf "%18s%18s%12g%12g%12g\n"              "16:52:58.918" "+2:24:04.15" "42.4" "19.1" "-70" >> "ListOfApertures.txt" # THIS IS NOT THE CrabPhotAperPhot FORMAT!
printf "%18s%18s%12g%12g%12g\n"              "16:52:58.918" "+2:24:04.15" "42.4" "19.1" "-70" >> "ListOfApertures.txt" # THIS IS NOT THE CrabPhotAperPhot FORMAT!
printf "%18s%18s%12g%12g%12g\n"              "16:52:58.918" "+2:24:04.15" "41.4" "25.8" "-70" >> "ListOfApertures.txt" # THIS IS NOT THE CrabPhotAperPhot FORMAT!
printf "%18s%18s%12g%12g%12g\n"              "16:52:58.918" "+2:24:04.15" "40.4" "35.5" "-70" >> "ListOfApertures.txt" # THIS IS NOT THE CrabPhotAperPhot FORMAT!
printf "image;ellipse(%s,%s,%g\",%g\",%g)\n" "16:52:58.918" "+2:24:04.15" "42.4" "19.1" "-70" >> "ListOfApertures.reg" # Major axis, minor axis, angle degree.
printf "image;ellipse(%s,%s,%g\",%g\",%g)\n" "16:52:58.918" "+2:24:04.15" "42.4" "19.1" "-70" >> "ListOfApertures.reg" # Major axis, minor axis, angle degree.
printf "image;ellipse(%s,%s,%g\",%g\",%g)\n" "16:52:58.918" "+2:24:04.15" "41.4" "25.8" "-70" >> "ListOfApertures.reg" # Major axis, minor axis, angle degree.
printf "image;ellipse(%s,%s,%g\",%g\",%g)\n" "16:52:58.918" "+2:24:04.15" "40.4" "35.5" "-70" >> "ListOfApertures.reg" # Major axis, minor axis, angle degree.
printf "%18s%18s%12g%12g%12g\n"              "16:52:49.402" "+2:26:41.45" "42.4" "19.1" "-70" >> "ListOfSkyApertures.txt" # Sky aperture
printf "%18s%18s%12g%12g%12g\n"              "16:52:49.402" "+2:26:41.45" "42.4" "19.1" "-70" >> "ListOfSkyApertures.txt" # Sky aperture
printf "%18s%18s%12g%12g%12g\n"              "16:52:49.402" "+2:26:41.45" "41.4" "25.8" "-70" >> "ListOfSkyApertures.txt" # Sky aperture
printf "%18s%18s%12g%12g%12g\n"              "16:52:49.402" "+2:26:41.45" "40.4" "35.5" "-70" >> "ListOfSkyApertures.txt" # Sky aperture
printf "image;ellipse(%s,%s,%g\",%g\",%g)\n" "16:52:49.402" "+2:26:41.45" "42.4" "19.1" "-70" >> "ListOfSkyApertures.reg" # Sky aperture
printf "image;ellipse(%s,%s,%g\",%g\",%g)\n" "16:52:49.402" "+2:26:41.45" "42.4" "19.1" "-70" >> "ListOfSkyApertures.reg" # Sky aperture
printf "image;ellipse(%s,%s,%g\",%g\",%g)\n" "16:52:49.402" "+2:26:41.45" "41.4" "25.8" "-70" >> "ListOfSkyApertures.reg" # Sky aperture
printf "image;ellipse(%s,%s,%g\",%g\",%g)\n" "16:52:49.402" "+2:26:41.45" "40.4" "35.5" "-70" >> "ListOfSkyApertures.reg" # Sky aperture
# 
# NGC6240 WISE W3 
# Brown et al. (2014) mAB = 9.57
# according to http://wise2.ipac.caltech.edu/docs/release/allsky/expsup/sec4_4h.html
# so mVega = mWISE = 9.57 - 5.174 = 4.396
# so fWISE = 10^(4.396/2.5) = 57.33


ls -1 ../../phot/MIPS_Photo_Repaired/*_mips_ch1_Repaired.fits >> "ListOfPhotos.txt"
printf "%12g\n" "24"  >> "ListOfWavelengths.txt"
printf "%12g\n" "0.0" >> "ListOfPhotoFluxZP.txt" # MIPS 24 pixel flux unit is MJy/sr
printf "%18s%18s%12g%12g%12g\n"              "16:52:58.918" "+2:24:04.15" "40.4" "35.5" "-70" >> "ListOfApertures.txt" # THIS IS NOT THE CrabPhotAperPhot FORMAT!
printf "image;ellipse(%s,%s,%g\",%g\",%g)\n" "16:52:58.918" "+2:24:04.15" "40.4" "35.5" "-70" >> "ListOfApertures.reg" # Major axis, minor axis, angle degree.
printf "%18s%18s%12g%12g%12g\n"              "16:52:49.402" "+2:26:41.45" "40.4" "35.5" "-70" >> "ListOfSkyApertures.txt" # Sky aperture
printf "image;ellipse(%s,%s,%g\",%g\",%g)\n" "16:52:49.402" "+2:26:41.45" "40.4" "35.5" "-70" >> "ListOfSkyApertures.reg" # Sky aperture

ls -1 ../../phot/PACS_Photo_Repaired/*_pacs70_0_Repaired.fits >> "ListOfPhotos.txt"
ls -1 ../../phot/PACS_Photo_Repaired/*_pacs100_0_Repaired.fits >> "ListOfPhotos.txt"
ls -1 ../../phot/PACS_Photo_Repaired/*_pacs160_0_Repaired.fits >> "ListOfPhotos.txt"
printf "%12g\n" "70" >> "ListOfWavelengths.txt"
printf "%12g\n" "100" >> "ListOfWavelengths.txt"
printf "%12g\n" "160" >> "ListOfWavelengths.txt"
printf "%12g\n" "0.0" >> "ListOfPhotoFluxZP.txt" # PACS pixel flux unit is Jy/pixel
printf "%12g\n" "0.0" >> "ListOfPhotoFluxZP.txt" # PACS pixel flux unit is Jy/pixel
printf "%12g\n" "0.0" >> "ListOfPhotoFluxZP.txt" # PACS pixel flux unit is Jy/pixel
printf "%18s%18s%12g%12g%12g\n"              "16:52:58.918" "+2:24:04.15" "40.4" "35.5" "-70" >> "ListOfApertures.txt" # THIS IS NOT THE CrabPhotAperPhot FORMAT!
printf "%18s%18s%12g%12g%12g\n"              "16:52:58.918" "+2:24:04.15" "40.4" "35.5" "-70" >> "ListOfApertures.txt" # THIS IS NOT THE CrabPhotAperPhot FORMAT!
printf "%18s%18s%12g%12g%12g\n"              "16:52:58.918" "+2:24:04.15" "40.4" "35.5" "-70" >> "ListOfApertures.txt" # THIS IS NOT THE CrabPhotAperPhot FORMAT!
printf "image;ellipse(%s,%s,%g\",%g\",%g)\n" "16:52:58.918" "+2:24:04.15" "40.4" "35.5" "-70" >> "ListOfApertures.reg" # Major axis, minor axis, angle degree.
printf "image;ellipse(%s,%s,%g\",%g\",%g)\n" "16:52:58.918" "+2:24:04.15" "40.4" "35.5" "-70" >> "ListOfApertures.reg" # Major axis, minor axis, angle degree.
printf "image;ellipse(%s,%s,%g\",%g\",%g)\n" "16:52:58.918" "+2:24:04.15" "40.4" "35.5" "-70" >> "ListOfApertures.reg" # Major axis, minor axis, angle degree.
printf "%18s%18s%12g%12g%12g\n"              "16:53:06.042" "+2:22:34.45" "40.4" "35.5" "-70" >> "ListOfSkyApertures.txt" # Sky aperture, different than WISE, MIPS positions
printf "%18s%18s%12g%12g%12g\n"              "16:53:06.042" "+2:22:34.45" "40.4" "35.5" "-70" >> "ListOfSkyApertures.txt" # Sky aperture
printf "%18s%18s%12g%12g%12g\n"              "16:53:06.042" "+2:22:34.45" "40.4" "35.5" "-70" >> "ListOfSkyApertures.txt" # Sky aperture
printf "image;ellipse(%s,%s,%g\",%g\",%g)\n" "16:53:06.042" "+2:22:34.45" "40.4" "35.5" "-70" >> "ListOfSkyApertures.reg" # Sky aperture
printf "image;ellipse(%s,%s,%g\",%g\",%g)\n" "16:53:06.042" "+2:22:34.45" "40.4" "35.5" "-70" >> "ListOfSkyApertures.reg" # Sky aperture
printf "image;ellipse(%s,%s,%g\",%g\",%g)\n" "16:53:06.042" "+2:22:34.45" "40.4" "35.5" "-70" >> "ListOfSkyApertures.reg" # Sky aperture




