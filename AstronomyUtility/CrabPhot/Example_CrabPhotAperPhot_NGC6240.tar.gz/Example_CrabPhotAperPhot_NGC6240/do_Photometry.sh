#!/bin/bash
#

InputPhotos=($(cat "ListOfPhotos.txt" | grep -v "^#"))
InputRegions=($(cat "ListOfApertures.reg" | grep -v "^#"))
InputSkyRegions=($(cat "ListOfSkyApertures.reg" | grep -v "^#"))
InputWavelengths=($(cat "ListOfWavelengths.txt" | grep -v "^#"))

rm -rf "ListOfFluxes.txt" 2>/dev/null
rm -rf "ListOfFluxErrors.txt" 2>/dev/null
rm -rf "flux.dat" 2>/dev/null

ds9 -title "NGC6240" -lock frame wcs -scale mode 99.5 ${InputPhotos[@]} &

while [[ $(xpaget "NGC6240" fits 2>&1 | grep ERROR | wc -l) -eq 1 ]]; do 
    sleep 1
done

for (( i=0; i<${#InputPhotos[@]}; i++ )); do
    xpaset -p "NGC6240" frame $(($i+1))
    echo ${InputRegions[$i]} | xpaset "NGC6240" regions
    echo ${InputSkyRegions[$i]} " # color=yellow" | xpaset "NGC6240" regions
    
    # deal with fits file name and extension
    TempFitsPath=$(echo ${InputPhotos[$i]} | sed -e 's/[[][0-9]*[]]$//g' | sed -e 's/\.fits$//g')
    TempFitsName=$(basename ${InputPhotos[$i]} | sed -e 's/[[][0-9]*[]]$//g' | sed -e 's/\.fits$//g')
    TempFitsExtn=$(basename ${InputPhotos[$i]} | sed -e 's/.*[[]\([0-9]*\)[]]$/\1/g' | grep -e '^[0-9]*$')
    if [[ x"$TempFitsExtn" == x"" ]]; then TempFitsExtn="0"; fi
    
    # run CrabPhotAperPhot
    mkdir "tmp_aperphot" 2>/dev/null
    echo "AperType = ellip" > "tmp_aperphot/$TempFitsName.aperphot.ini"
    TempAperPars=($(cat "ListOfApertures.txt" | grep -v "^#" | sed -n "$(($i+1))p" | tr -s ' '))
    TempAperPosX=$(sky2xy "$TempFitsPath.fits" ${TempAperPars[0]} ${TempAperPars[1]} | tr -s ' ' | cut -d ' ' -f 5)
    TempAperPosY=$(sky2xy "$TempFitsPath.fits" ${TempAperPars[0]} ${TempAperPars[1]} | tr -s ' ' | cut -d ' ' -f 6)
    #          echo "xy2sky -d -n 10 \"$TempFitsPath.fits\" $TempAperPosX "$(bc -l <<< "$TempAperPosY+0.0")
    #          echo "xy2sky -d -n 10 \"$TempFitsPath.fits\" $TempAperPosX "$(bc -l <<< "$TempAperPosY+1.0")
    TempAperPosDec=$(xy2sky -d -n 10 "$TempFitsPath.fits" $TempAperPosX $(bc -l <<< "$TempAperPosY+0.0") | tr -s ' ' | cut -d ' ' -f 2)
    TempAperRefDec=$(xy2sky -d -n 10 "$TempFitsPath.fits" $TempAperPosX $(bc -l <<< "$TempAperPosY+1.0") | tr -s ' ' | cut -d ' ' -f 2)
    TempPixelScale=$(bc -l <<< "(($TempAperRefDec)-($TempAperPosDec))*3600.0") # "/pixel
    TempAperRadius=$(bc -l <<< "${TempAperPars[2]}/$TempPixelScale") # Radius in pixel
    TempAperEllips=$(bc -l <<< "${TempAperPars[3]}/${TempAperPars[2]}") # Ellips is the Minor/Major b/a ratio
    TempAperRotate=${TempAperPars[4]}
    printf "%12g%12g%12g%12g%12g\n" $TempAperPosX $TempAperPosY $TempAperRadius $TempAperEllips $TempAperRotate > "tmp_aperphot/$TempFitsName.aperphot.inp"
    echo ./CrabPhotAperPhot_linux_x86_64 "\\"
    echo "$TempFitsPath.fits" "-ext" "$TempFitsExtn" "\\"
    echo "tmp_aperphot/$TempFitsName.aperphot.ini" "\\"
    echo "tmp_aperphot/$TempFitsName.aperphot.inp" ">" "\\"
    echo "tmp_aperphot/$TempFitsName.aperphot.out"
    ./CrabPhotAperPhot_linux_x86_64 "$TempFitsPath.fits" -ext "$TempFitsExtn" "tmp_aperphot/$TempFitsName.aperphot.ini" "tmp_aperphot/$TempFitsName.aperphot.inp" > "tmp_aperphot/$TempFitsName.aperphot.out"
    #cat "tmp_aperphot/$TempFitsName.aperphot.out"
    TempAperFlux=$(CrabTableReadColumn "tmp_aperphot/$TempFitsName.aperphot.out" "sum" | tail -n +2 | sed -e 's/ //g')
    if [[ x"$TempAperFlux" == x"" ]]; then echo "Error! Failed to get good results from CrabPhotAperPhot! Is fits file extension correct?"; exit -1; fi
    
    # run CrabPhotAperPhot for sky aperture
    echo "AperType = ellip" > "tmp_aperphot/$TempFitsName.skyaperphot.ini"
    TempSkyAperPars=($(cat "ListOfSkyApertures.txt" | grep -v "^#" | sed -n "$(($i+1))p" | tr -s ' '))
    TempSkyAperPosX=$(sky2xy "$TempFitsPath.fits" ${TempSkyAperPars[0]} ${TempSkyAperPars[1]} | tr -s ' ' | cut -d ' ' -f 5)
    TempSkyAperPosY=$(sky2xy "$TempFitsPath.fits" ${TempSkyAperPars[0]} ${TempSkyAperPars[1]} | tr -s ' ' | cut -d ' ' -f 6)
    printf "%12g%12g%12g%12g%12g\n" $TempSkyAperPosX $TempSkyAperPosY $TempAperRadius $TempAperEllips $TempAperRotate > "tmp_aperphot/$TempFitsName.skyaperphot.inp"
    echo ./CrabPhotAperPhot_linux_x86_64 "\\"
    echo "$TempFitsPath.fits" "-ext" "$TempFitsExtn" "\\"
    echo "tmp_aperphot/$TempFitsName.skyaperphot.ini" "\\"
    echo "tmp_aperphot/$TempFitsName.skyaperphot.inp" ">" "\\"
    echo "tmp_aperphot/$TempFitsName.skyaperphot.out"
    ./CrabPhotAperPhot_linux_x86_64 "$TempFitsPath.fits" -ext "$TempFitsExtn" "tmp_aperphot/$TempFitsName.skyaperphot.ini" "tmp_aperphot/$TempFitsName.skyaperphot.inp" > "tmp_aperphot/$TempFitsName.skyaperphot.out"
    #cat "tmp_aperphot/$TempFitsName.skyaperphot.out"
    TempSkyAperFlux=$(CrabTableReadColumn "tmp_aperphot/$TempFitsName.skyaperphot.out" "sum" | tail -n +2 | sed -e 's/ //g')
    if [[ x"$TempSkyAperFlux" == x"" ]]; then echo "Error! Failed to get good results from CrabPhotAperPhot for sky background! Is fits file extension correct?"; exit -1; fi
    
    # convert to flux Jy
    TempPhotFluxZP=$(cat "ListOfPhotoFluxZP.txt" | grep -v "^#" | sed -n "$(($i+1))p" | sed -e 's/ //g')
    echo "converting flux to Jy"
    if [[ $(bc -l <<< "$TempPhotFluxZP>0") -eq 1 ]]; then
        TempPhotBUNIT=$(gethead "$TempFitsPath.fits" "BUNIT")
        TempPhotMagZP=$(gethead "$TempFitsPath.fits" "MAGZP")
        echo "fluxzeropoint $TempPhotFluxZP"
        echo "magzeropoint $TempPhotMagZP"
        TempPhotFluxConv=$(idl -quiet -e "print, $TempPhotFluxZP/(10^($TempPhotMagZP/2.5))" | sed -e 's/ //g')
        TempAperFlux=$(idl -quiet -e "print, $TempAperFlux*$TempPhotFluxConv" | sed -e 's/ //g')
        TempSkyAperFlux=$(idl -quiet -e "print, $TempSkyAperFlux*$TempPhotFluxConv" | sed -e 's/ //g')
        TempNetFlux=$(idl -quiet -e "print, $TempAperFlux-($TempSkyAperFlux)" | sed -e 's/ //g')
        echo "fluxconv $TempPhotFluxConv (Jy/pixel)/(DN)"
    else
        TempPhotBUNIT=$(gethead "$TempFitsPath.fits" "BUNIT")
        if [[ x"$TempPhotBUNIT" == x*"MJy"*"sr"* ]]; then
            TempPhotFluxConv=$(idl -quiet -e "print, 2.350443e-5*$TempPixelScale^2" | sed -e 's/ //g')
            TempAperFlux=$(idl -quiet -e "print, $TempAperFlux*$TempPhotFluxConv" | sed -e 's/ //g')
            TempSkyAperFlux=$(idl -quiet -e "print, $TempSkyAperFlux*$TempPhotFluxConv" | sed -e 's/ //g')
            TempNetFlux=$(idl -quiet -e "print, $TempAperFlux-($TempSkyAperFlux)" | sed -e 's/ //g')
            echo "fluxconv $TempPhotFluxConv (Jy/pixel)/(MJy/sr)"
        fi
        if [[ x"$TempPhotBUNIT" == x*"Jy"*"pix"* ]]; then
            TempNetFlux=$(idl -quiet -e "print, $TempAperFlux-($TempSkyAperFlux)" | sed -e 's/ //g')
            echo "fluxconv is unity (already Jy/pixel)"
        fi
        if [[ x"$TempPhotBUNIT" == x*"COUNTS/S"* || x"$TempPhotBUNIT" == x*"ELECTRONS/S" ]]; then
            # no BUNIT
            TempPhotPHOTFLAM=$(gethead "$TempFitsPath.fits" "PHOTFLAM")
            TempPhotPHOTPLAM=$(gethead "$TempFitsPath.fits" "PHOTPLAM")
            if [[ x"$TempPhotPHOTFLAM" != x"" && x"$TempPhotPHOTPLAM" != x"" ]]; then
                # HST ACS 
                # http://www.stsci.edu/hst/acs/analysis/zeropoints
                TempPhotFluxConv=$(idl -quiet -e "print, $TempPhotPHOTFLAM*$TempPhotPHOTPLAM/(2.99792458e8/($TempPhotPHOTPLAM*1e-10))/1e-23" | sed -e 's/ //g') # convert erg/s/cm2/AA to erg/s/cm2/Hz then Jy
                TempAperFlux=$(idl -quiet -e "print, $TempAperFlux*$TempPhotFluxConv" | sed -e 's/ //g')
                TempSkyAperFlux=$(idl -quiet -e "print, $TempSkyAperFlux*$TempPhotFluxConv" | sed -e 's/ //g')
                TempNetFlux=$(idl -quiet -e "print, $TempAperFlux-($TempSkyAperFlux)" | sed -e 's/ //g')
                echo "fluxconv $TempPhotFluxConv (Jy/pixel)/(COUNTS/S)"
            fi
        fi
        # default is "Jy/pixel" like PACS photo
    fi
    
    # write to file and show on DS9
    echo "writing to files"
    if [[ $(idl -quiet -e "print, ($TempPhotFluxConv GT 0)" | sed -e 's/ //g') -eq 1 ]]; then
        # write to file
        printf "%g\n" $TempPhotFluxConv > "tmp_aperphot/$TempFitsName.aperphot.fluxconv"
        printf "%g\n" $TempAperFlux     > "tmp_aperphot/$TempFitsName.aperphot.fluxvalue"
        printf "%g\n" $TempSkyAperFlux  > "tmp_aperphot/$TempFitsName.skyaperphot.fluxvalue"
        printf "%g\n" $TempNetFlux      > "tmp_aperphot/$TempFitsName.skysubtracted.fluxvalue"
        printf "%18g\n" $TempNetFlux   >> "ListOfFluxes.txt"
        # write to flux.dat
        if [[ ! -f "flux.dat" ]]; then
            printf "%1s%14s%15s%15s\n" "#" "wave" "flux" "error" > "flux.dat"
            printf "#\n" >> "flux.dat"
        fi
        printf "%15g%15g%15g\n" ${InputWavelengths[$i]} \
                                 $(idl -quiet -e "print, $TempNetFlux*1e3" | sed -e 's/ //g') \
                                 $(idl -quiet -e "print, $TempNetFlux*1e3*0.15" | sed -e 's/ //g') \
                                 >> "flux.dat" # flux in mJy for SED fitting #<TODO># flux errors
        # print on screen
        echo "aperflux $TempAperFlux [Jy]"
        echo "skyaperflux $TempSkyAperFlux [Jy]"
        echo "skysubtractedflux $TempNetFlux [Jy]"
        # show on DS9
        echo "image;text($TempAperPosX,"$(bc -l <<< "$TempAperPosY+$TempAperRadius")")#text={$TempNetFlux[Jy]}" | xpaset "NGC6240" regions
        echo "image;text($TempSkyAperPosX,"$(bc -l <<< "$TempSkyAperPosY+$TempAperRadius")")#text={sky} color=yellow" | xpaset "NGC6240" regions
    fi
    
    #
    echo "-----------------------------------------------------------------------------------------------------" 
    
done




if [[ 1 == 1 ]]; then
    echo "writing to \"fit_SED_michi2\""
    mkdir "fit_SED_michi2" 2>/dev/null
    # printf "%1s%11s%18s%18s\n" "#" "wave" "flux" "error" > "fit_SED_michi2/flux.dat"
    # printf "#\n" >> "fit_SED_michi2/flux.dat"
    # pr -mts "ListOfWavelengths.txt" "ListOfFluxes.txt" "ListOfFluxErrors.txt" >> "fit_SED_michi2/flux.dat"
    cp "flux.dat" "fit_SED_michi2/flux.dat" 
    cp "flux.dat" "fit_SED_michi2/flux_obsframe.dat"
    #cp "/home/dzliu/Cloud/SpireLines/Tool/Level_3_SciData/07_SED_Synthesis/04_Plot_Best_Chi2/runsed_triple.sh" "fit_SED_michi2/"
    #cp "/home/dzliu/Cloud/SpireLines/Tool/Level_3_SciData/07_SED_Synthesis/03_Minimize_Chi2/michi2_v02_201509_DL07_Linux_x86_64" "fit_SED_michi2/mich2"
    #grep "^Redshift " ../../info/[^._~]*.ini
    echo "done!"
fi



