### Plot the SEDs with best chi<sup>2</sup>

An IDL code to plot the SEDs with best chi<sup>2</sup> fitting. 



