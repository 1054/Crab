#!/bin/bash
#

currentdir="$(pwd -P)"
scriptdir="${BASH_SOURCE[0]}"

cd "${scriptdir}"
idl << EOF

EOF

cd "${currentdir}"


