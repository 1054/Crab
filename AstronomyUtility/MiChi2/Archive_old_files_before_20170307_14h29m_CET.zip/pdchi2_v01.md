### Probability Distribution of chi<sup>2</sup>

An IDL code to compute the PDF of each parameter in a chi<sup>2</sup> fitting. 



