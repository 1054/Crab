#!/bin/bash
#
/isaac/u/dzliu/Cloud/Github/Crab.Toolkit.michi2/bin/michi2-plot-results-of-fitting-5-components $@
