#ifndef __GAUSSMODEL__H
#define __GAUSSMODEL__H

#include <BAT/BCModel.h>

// ---------------------------------------------------------
class BATModel : public BCModel
{
   public:

      // Constructors and destructor
      BATModel();
      BATModel(const char * name);
      ~BATModel();

      // Methods to overload, see file BATModel.cxx
      void DefineParameters();
      double LogAPrioriProbability(const std::vector<double> &parameters);
      double LogLikelihood(const std::vector<double> &parameters);

      // overloaded trial function
      /* 
      virtual double MCMCTrialFunctionSingle(unsigned int ichain, unsigned int ipar);
      */
};
// ---------------------------------------------------------

#endif

