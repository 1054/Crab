/*
 * Copyright (C) 2009, Daniel Kollar and Kevin Kroeninger.
 * All rights reserved.
 *
 * For the licensing terms see doc/COPYING.
 */

#include <iostream>

#include "include/QuickTestSuite.h"

namespace BAT {

   //______________________________________________________________________________
   QuickTestSuite::QuickTestSuite()
   {
   }

   //______________________________________________________________________________
   QuickTestSuite::~QuickTestSuite()
   {
   }

   //______________________________________________________________________________
   //______________________________________________________________________________

} // end namespace BAT
