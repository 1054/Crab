BAT - Bayesian Analysis Toolkit
===============================

Release notes for version:    0.9.4.1
Release date:                 2015-01-19
Urgency:                      low

Bug fixes
---------

* fix installation on Mac OS X with root6 and a version of `sed` that
  is incompatible with GNU `sed` to avoid errors when using `sed -i`.
