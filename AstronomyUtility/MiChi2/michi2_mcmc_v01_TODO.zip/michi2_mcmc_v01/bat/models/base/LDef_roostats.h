#ifndef LDef_roostats_h
#define LDef_roostats_h

#ifdef __CINT__

// No "pragma link off" statements here as this file comes after LDef.h .

#pragma link C++ class BCRooInterface-;
#pragma link C++ class RooStats::BATCalculator+;

#pragma link C++ namespace RooStats;


#endif

#endif // LDef_roostats_h
