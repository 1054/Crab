#ifndef LDef_h
#define LDef_h

#ifdef __CINT__


#pragma link off all globals;
#pragma link off all classes;
#pragma link off all functions;


#pragma link C++ class BCFitter-;
#pragma link C++ class BCGraphFitter-;
#pragma link C++ class BCEfficiencyFitter-;
#pragma link C++ class BCHistogramFitter-;


#endif

#endif // LDef_h
