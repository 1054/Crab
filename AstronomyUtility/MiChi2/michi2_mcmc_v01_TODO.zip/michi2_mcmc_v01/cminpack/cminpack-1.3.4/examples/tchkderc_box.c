#define BOX_CONSTRAINTS
#include "tchkderc.c"
