#include <stdio.h>
#include <stdlib.h> /* srand, rand */
#include <time.h> /* time */
#include <math.h>
#include <string>
#include <vector>
#include <iostream>
#include <sstream>
#include <fstream>
#include "minpack.h"
#include "lmdif1_.c"
#include "lmdif_.c"
#include "lmpar_.c"
#include "dpmpar_.c"
#include "enorm_.c"
#include "fdjac2_.c"
#include "qrfac_.c"
#include "qrsolv_.c"
#include "../CrabTableReadColumn.cpp"

using namespace std;



double * independent_variables;

double * observed_variables;

double ** library_variables;

void fcn(const int *m, const int *n, const double *x, double *fvec, int *iflag);

void fcn(const int *m, const int *n, const double *x, double *fvec, int *iflag)
{
    /* calculate the functions at x and return
     the values in fvec[0] through fvec[m-1] */
    const double * fit_parameters = x;
    for (int iim=0; iim<(*m); iim++) {
        double fit_variable_sum = 0.0;
        for (int iin=0; iin<(*n); iin++) {
            fit_variable_sum += fit_parameters[iin]*library_variables[iin][iim];
            // library_variables is the functions of independent_variables.
        }
        fvec[iim] = fit_variable_sum - observed_variables[iim];
    }
}

int main(int argc, char **argv)
{
    /**
     // You’ll notice that argv[0] is the path and name of the program itself.
     std::cout << "CrabTableReadInfo: Input " << argc-1 << " arguments." << std::endl;
     for (int i = 0; i < argc; ++i) {
     std::cout << argv[i] << std::endl;
     }
     **/
    if(argc>=1)
    {
        // lmdif1_
        int m = 20;                    // NVAR1 N_independent_variable (NAXIS1)
        int n = 5;                     // NCOEF N_coefficiencies // for single LVG n=1, for double LVG n=2, for SED n=3. 
        double *x = new double[n];     // parameters vector
        double *fvec = new double[m];  // chi-square vector
        double ftol = 1e-08;           // tolerance
        int info = 3;                  // output fit information see manual html
        int lwa = m*n + 5*n + m;       // for internal use
        double *wa = new double[lwa];  // for internal use
        int *iwa = new int[n];         // for internal use
        //
        // prepare vectors
        // independent_variables = new double[m];
        // observed_variables = new double[n];
        // library_variables = new double*[n];
        // for(int iin=0; iin<n; iin++) { library_variables[iin] = new double[m]; }
        //
        // set data
        // for(int i=1; i<=m; i++) {
        //     independent_variables[i] = (double)i;
        //     srand (time(NULL));
        //     observed_variables[i] = 29.5*(double)i+18.25+(rand()%5+1)*0.00;
        // }
        //
        //
        // read data from dat / lvg
        independent_variables = CrabTableReadColumnF("test.dat",1);
        observed_variables = CrabTableReadColumnF("test.dat",2);
        library_variables = new double*[n];
        for(int iin=0; iin<n; iin++) {
            char libfile[250];  sprintf(libfile,"lib%0d.lvg",iin+1);
            library_variables[iin] = CrabTableReadColumnF(libfile,2);
        }
        // print on screen
        std::cout << "VAR1 = ";
        for(int i=1; i<=m; i++) {
            std::cout << independent_variables[i-1] << " ";
        }   std::cout << std::endl;
        std::cout << "VAR2 = ";
        for(int i=1; i<=m; i++) {
            std::cout << observed_variables[i-1] << " ";
        }   std::cout << std::endl;
        //
        // initialize fitting parameters
        for(int i=1; i<=n; i++) {
            x[i-1] = 0.1;
        }
        //
        lmdif1_( fcn, &m, &n, x, fvec, &ftol, &info, iwa, wa, &lwa);
        std::cout << "m=" << m << " n=" << n ;
        for(int i=0; i<n; i++) {
            std::cout << " a[" << i << "]=" << x[i];
        }
        std::cout << " info=" << info << std::endl;
        // 
    }
    return 0;
}
