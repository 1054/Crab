#include "BATModel.h"

#include <BAT/BCMath.h>
#include <BAT/BCParameter.h>

//#include <TRandom3.h>

#include <cmath>
#include <iostream>

// ---------------------------------------------------------
BATModel::BATModel() : BCModel()
{
  // default constructor
  DefineParameters();
};

// ---------------------------------------------------------
BATModel::BATModel(const char * name) : BCModel(name)
{
  // constructor
  DefineParameters();
};

// ---------------------------------------------------------
BATModel::~BATModel()
// default destructor
{
};

// ---------------------------------------------------------
void BATModel::DefineParameters()
{
  // add parameters x and y
  AddParameter("PAR1",  00.0, 700.0, "T_{kin}"); // index 0
  AddParameter("PAR2",   2.0,   6.0, "n_{H_2}"); // index 1
}

// ---------------------------------------------------------
double BATModel::LogLikelihood(const std::vector<double> &parameters)
{
  // assume a simple Gaussian Likelihood with two independent
  // variables
  double logprob = 0.;

  double x = parameters.at(0);
  double y = parameters.at(1);
    
    
    // min chi2 by 1 component fit
    std::vector<std::vector<double> > fLIB;
    fLIB.push_back(SDDAT.f1);
    std::vector<double> fOBS = SDDAT.f0;
    std::vector<double> eOBS = SDDAT.df;
    
    michi2MinPack *MPACK = new michi2MinPack(fLIB,fOBS,eOBS);
    std::vector<double> f1 = SDLIB->Y;
    double a1 = MPACK->aCOE[0];
    double chi2 = 0.0; for(int j=0;j<MPACK->chi2.size();j++) {chi2+=MPACK->chi2[j];}
    delete MPACK;
    
    
    logprob = exp(-chi2);
    
    return logprob;
}

// ---------------------------------------------------------
double BATModel::LogAPrioriProbability(const std::vector<double> &parameters)
{
  // assume flat prior in both variables
  double logprob = 0.;

  double dx = GetParameter(0)->GetRangeWidth();
  double dy = GetParameter(1)->GetRangeWidth();

  logprob += log(1./dx); // flat prior for x
  logprob += log(1./dy); // flat prior for y

  return logprob;
}

// --------------------------------------------------------
/*
double BATModel::MCMCTrialFunctionSingle(unsigned int ichain, unsigned int ipar)
{
  // no check of range for performance reasons

  // get scale factor from an array of scale factors. the size of the
  // array is number of chains times number of parameters.
  // double scale = fMCMCTrialFunctionScaleFactor[ichain * GetNParameters() + ipar];

  // choose trial function by uncommenting any of the lines below

  // Gaussian with fixed width
  //  return fRandom->Gaus(0.0, 1.0);

  // Gaussian with adjustable width
  //  return fRandom->Gaus(0.0, scale);

  // Breit-Wigner with adjustable width
  //  return fRandom->BreitWigner(0.0, scale);

  // Flat function with adjustable width
  //  return scale * 2. * (0.5 - fRandom->Uniform());

  // Flat function with fixed width
  return 0.02 * (0.5 - fRandom->Uniform());

}
*/
// ---------------------------------------------------------

