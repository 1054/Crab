/********************************************************************************
** Form generated from reading UI file 'crabmultimediaplayer.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CRABMULTIMEDIAPLAYER_H
#define UI_CRABMULTIMEDIAPLAYER_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QOpenGLWidget>
#include <QtWidgets/QProgressBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_CrabMultiMediaPlayer
{
public:
    QGridLayout *gridLayout;
    QVBoxLayout *verticalLayout_2;
    QOpenGLWidget *openGLWidget;
    QProgressBar *progressBar;
    QHBoxLayout *horizontalLayout;
    QVBoxLayout *verticalLayout;
    QPushButton *buttonPlayList;
    QPushButton *buttonLyrics;
    QPushButton *buttonPlay;
    QTextEdit *textEditPlayList;
    QTextEdit *textEditLyrics;
    QLineEdit *statusBar;

    void setupUi(QWidget *CrabMultiMediaPlayer)
    {
        if (CrabMultiMediaPlayer->objectName().isEmpty())
            CrabMultiMediaPlayer->setObjectName(QStringLiteral("CrabMultiMediaPlayer"));
        CrabMultiMediaPlayer->resize(417, 361);
        CrabMultiMediaPlayer->setAutoFillBackground(false);
        CrabMultiMediaPlayer->setStyleSheet(QLatin1String("#CrabMultiMediaPlayer {\n"
"    background: rgb(10,10,10);\n"
"}\n"
"\n"
"QOpenGLWidget {\n"
"}\n"
"\n"
"QProgressBar {\n"
"    background-color: rgb(10,10,10);\n"
"    border: 0.5px solid grey;\n"
"    border-radius: 5px;\n"
"}\n"
"\n"
"QProgressBar:chunk {\n"
"    background-color: #CD96CD;\n"
"    margin: 0.5px;\n"
"    width: 3px;\n"
"}\n"
"\n"
"QTextEdit {\n"
"    color: gray; \n"
"    background-color: rgb(10,10,10);\n"
"    border: 1px solid;\n"
"    border-radius: 5px; \n"
"    border-color: gray;\n"
"}\n"
"\n"
"QPushButton {\n"
"    color: gray; \n"
"    background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 rgb(60,60,60), stop: 1 rgb(10,10,10));\n"
"    margin: 1px;\n"
"    padding: 1px;\n"
"    border-color: gray;\n"
"    border-style: outset;\n"
"    border-radius: 3px;\n"
"    border-width: 1px;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 rgb(10,10,10), stop: 1 rgb(60,60,60));\n"
"}\n"
"\n"
"QLineEdit {\n"
"    c"
                        "olor: gray; \n"
"    background-color: rgb(10,10,10);\n"
"    border-width: 0px;\n"
"}"));
        gridLayout = new QGridLayout(CrabMultiMediaPlayer);
        gridLayout->setSpacing(3);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        gridLayout->setContentsMargins(3, 3, 3, 1);
        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setSpacing(0);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        openGLWidget = new QOpenGLWidget(CrabMultiMediaPlayer);
        openGLWidget->setObjectName(QStringLiteral("openGLWidget"));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(openGLWidget->sizePolicy().hasHeightForWidth());
        openGLWidget->setSizePolicy(sizePolicy);
        openGLWidget->setMinimumSize(QSize(0, 45));
        openGLWidget->setMaximumSize(QSize(16777215, 40));
        openGLWidget->setAutoFillBackground(false);
        openGLWidget->setStyleSheet(QStringLiteral(""));

        verticalLayout_2->addWidget(openGLWidget);

        progressBar = new QProgressBar(CrabMultiMediaPlayer);
        progressBar->setObjectName(QStringLiteral("progressBar"));
        progressBar->setMinimumSize(QSize(0, 10));
        progressBar->setMaximumSize(QSize(16777215, 10));
        progressBar->setValue(24);
        progressBar->setTextVisible(false);
        progressBar->setInvertedAppearance(false);

        verticalLayout_2->addWidget(progressBar);


        gridLayout->addLayout(verticalLayout_2, 0, 0, 1, 1);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(0);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setSpacing(0);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        buttonPlayList = new QPushButton(CrabMultiMediaPlayer);
        buttonPlayList->setObjectName(QStringLiteral("buttonPlayList"));
        QSizePolicy sizePolicy1(QSizePolicy::Preferred, QSizePolicy::Minimum);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(buttonPlayList->sizePolicy().hasHeightForWidth());
        buttonPlayList->setSizePolicy(sizePolicy1);
        buttonPlayList->setMinimumSize(QSize(0, 25));

        verticalLayout->addWidget(buttonPlayList);

        buttonLyrics = new QPushButton(CrabMultiMediaPlayer);
        buttonLyrics->setObjectName(QStringLiteral("buttonLyrics"));
        sizePolicy1.setHeightForWidth(buttonLyrics->sizePolicy().hasHeightForWidth());
        buttonLyrics->setSizePolicy(sizePolicy1);
        buttonLyrics->setMinimumSize(QSize(0, 25));

        verticalLayout->addWidget(buttonLyrics);


        horizontalLayout->addLayout(verticalLayout);

        buttonPlay = new QPushButton(CrabMultiMediaPlayer);
        buttonPlay->setObjectName(QStringLiteral("buttonPlay"));
        QSizePolicy sizePolicy2(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(buttonPlay->sizePolicy().hasHeightForWidth());
        buttonPlay->setSizePolicy(sizePolicy2);
        buttonPlay->setMinimumSize(QSize(60, 60));
        buttonPlay->setAutoFillBackground(false);
        buttonPlay->setAutoDefault(true);
        buttonPlay->setFlat(false);

        horizontalLayout->addWidget(buttonPlay);


        gridLayout->addLayout(horizontalLayout, 0, 1, 1, 1);

        textEditPlayList = new QTextEdit(CrabMultiMediaPlayer);
        textEditPlayList->setObjectName(QStringLiteral("textEditPlayList"));
        QSizePolicy sizePolicy3(QSizePolicy::Minimum, QSizePolicy::Preferred);
        sizePolicy3.setHorizontalStretch(0);
        sizePolicy3.setVerticalStretch(0);
        sizePolicy3.setHeightForWidth(textEditPlayList->sizePolicy().hasHeightForWidth());
        textEditPlayList->setSizePolicy(sizePolicy3);
        textEditPlayList->setMinimumSize(QSize(120, 0));
        textEditPlayList->setFrameShape(QFrame::Panel);
        textEditPlayList->setFrameShadow(QFrame::Plain);

        gridLayout->addWidget(textEditPlayList, 1, 1, 1, 1);

        textEditLyrics = new QTextEdit(CrabMultiMediaPlayer);
        textEditLyrics->setObjectName(QStringLiteral("textEditLyrics"));
        textEditLyrics->setAutoFillBackground(false);
        textEditLyrics->setFrameShape(QFrame::NoFrame);
        textEditLyrics->setFrameShadow(QFrame::Plain);

        gridLayout->addWidget(textEditLyrics, 1, 0, 1, 1);

        statusBar = new QLineEdit(CrabMultiMediaPlayer);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        QSizePolicy sizePolicy4(QSizePolicy::Expanding, QSizePolicy::Fixed);
        sizePolicy4.setHorizontalStretch(0);
        sizePolicy4.setVerticalStretch(0);
        sizePolicy4.setHeightForWidth(statusBar->sizePolicy().hasHeightForWidth());
        statusBar->setSizePolicy(sizePolicy4);
        statusBar->setMinimumSize(QSize(0, 20));
        statusBar->setMaximumSize(QSize(16777215, 20));
        statusBar->setAutoFillBackground(false);
        statusBar->setFrame(false);
        statusBar->setClearButtonEnabled(false);

        gridLayout->addWidget(statusBar, 2, 0, 1, 2);

        gridLayout->setColumnStretch(0, 5);
        gridLayout->setColumnStretch(1, 1);
        QWidget::setTabOrder(buttonPlay, buttonPlayList);
        QWidget::setTabOrder(buttonPlayList, buttonLyrics);
        QWidget::setTabOrder(buttonLyrics, textEditLyrics);
        QWidget::setTabOrder(textEditLyrics, textEditPlayList);
        QWidget::setTabOrder(textEditPlayList, statusBar);

        retranslateUi(CrabMultiMediaPlayer);

        buttonPlay->setDefault(true);


        QMetaObject::connectSlotsByName(CrabMultiMediaPlayer);
    } // setupUi

    void retranslateUi(QWidget *CrabMultiMediaPlayer)
    {
        CrabMultiMediaPlayer->setWindowTitle(QApplication::translate("CrabMultiMediaPlayer", "CrabMultiMediaPlayer", 0));
        buttonPlayList->setText(QApplication::translate("CrabMultiMediaPlayer", "PlayList", 0));
        buttonLyrics->setText(QApplication::translate("CrabMultiMediaPlayer", "Lyrics", 0));
        buttonPlay->setText(QApplication::translate("CrabMultiMediaPlayer", "Play", 0));
    } // retranslateUi

};

namespace Ui {
    class CrabMultiMediaPlayer: public Ui_CrabMultiMediaPlayer {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CRABMULTIMEDIAPLAYER_H
