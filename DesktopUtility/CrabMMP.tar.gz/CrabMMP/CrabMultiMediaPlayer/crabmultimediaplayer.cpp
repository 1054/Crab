#include "crabmultimediaplayer.h"
#include "ui_crabmultimediaplayer.h"

CrabMultiMediaPlayer::CrabMultiMediaPlayer(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::CrabMultiMediaPlayer)
{
    ui->setupUi(this);
}

CrabMultiMediaPlayer::~CrabMultiMediaPlayer()
{
    delete ui;
}
