#ifndef CRABMULTIMEDIAPLAYER_H
#define CRABMULTIMEDIAPLAYER_H

#include <QWidget>

namespace Ui {
class CrabMultiMediaPlayer;
}

class CrabMultiMediaPlayer : public QWidget
{
    Q_OBJECT

public:
    explicit CrabMultiMediaPlayer(QWidget *parent = 0);
    ~CrabMultiMediaPlayer();

private:
    Ui::CrabMultiMediaPlayer *ui;
};

#endif // CRABMULTIMEDIAPLAYER_H
