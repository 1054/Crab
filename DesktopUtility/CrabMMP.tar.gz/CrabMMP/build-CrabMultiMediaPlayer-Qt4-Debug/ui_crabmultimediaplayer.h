/********************************************************************************
** Form generated from reading UI file 'crabmultimediaplayer.ui'
**
** Created by: Qt User Interface Compiler version 4.8.5
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CRABMULTIMEDIAPLAYER_H
#define UI_CRABMULTIMEDIAPLAYER_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QGridLayout>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLCDNumber>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QProgressBar>
#include <QtGui/QPushButton>
#include <QtGui/QTextEdit>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>
#include <qopenglwidget.h>

QT_BEGIN_NAMESPACE

class Ui_CrabMultiMediaPlayer
{
public:
    QGridLayout *gridLayout;
    QVBoxLayout *verticalLayout_2;
    QOpenGLWidget *openGLWidget;
    QProgressBar *progressBar;
    QHBoxLayout *horizontalLayout;
    QVBoxLayout *verticalLayout;
    QLCDNumber *lcdNumber;
    QLabel *label;
    QPushButton *pushButton;
    QTextEdit *textEdit_2;
    QTextEdit *textEdit;
    QLineEdit *lineEdit;

    void setupUi(QWidget *CrabMultiMediaPlayer)
    {
        if (CrabMultiMediaPlayer->objectName().isEmpty())
            CrabMultiMediaPlayer->setObjectName(QString::fromUtf8("CrabMultiMediaPlayer"));
        CrabMultiMediaPlayer->resize(417, 361);
        gridLayout = new QGridLayout(CrabMultiMediaPlayer);
        gridLayout->setSpacing(3);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        gridLayout->setContentsMargins(3, 3, 3, 1);
        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setSpacing(0);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        openGLWidget = new QOpenGLWidget(CrabMultiMediaPlayer);
        openGLWidget->setObjectName(QString::fromUtf8("openGLWidget"));
        openGLWidget->setMinimumSize(QSize(0, 36));

        verticalLayout_2->addWidget(openGLWidget);

        progressBar = new QProgressBar(CrabMultiMediaPlayer);
        progressBar->setObjectName(QString::fromUtf8("progressBar"));
        progressBar->setValue(24);

        verticalLayout_2->addWidget(progressBar);


        gridLayout->addLayout(verticalLayout_2, 0, 0, 1, 1);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(0);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setSpacing(0);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        lcdNumber = new QLCDNumber(CrabMultiMediaPlayer);
        lcdNumber->setObjectName(QString::fromUtf8("lcdNumber"));

        verticalLayout->addWidget(lcdNumber);

        label = new QLabel(CrabMultiMediaPlayer);
        label->setObjectName(QString::fromUtf8("label"));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Minimum);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(label->sizePolicy().hasHeightForWidth());
        label->setSizePolicy(sizePolicy);
        label->setMinimumSize(QSize(80, 0));

        verticalLayout->addWidget(label);


        horizontalLayout->addLayout(verticalLayout);

        pushButton = new QPushButton(CrabMultiMediaPlayer);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        QSizePolicy sizePolicy1(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(pushButton->sizePolicy().hasHeightForWidth());
        pushButton->setSizePolicy(sizePolicy1);
        pushButton->setMinimumSize(QSize(50, 50));

        horizontalLayout->addWidget(pushButton);


        gridLayout->addLayout(horizontalLayout, 0, 1, 1, 1);

        textEdit_2 = new QTextEdit(CrabMultiMediaPlayer);
        textEdit_2->setObjectName(QString::fromUtf8("textEdit_2"));
        QSizePolicy sizePolicy2(QSizePolicy::Minimum, QSizePolicy::Preferred);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(textEdit_2->sizePolicy().hasHeightForWidth());
        textEdit_2->setSizePolicy(sizePolicy2);
        textEdit_2->setMinimumSize(QSize(120, 0));

        gridLayout->addWidget(textEdit_2, 1, 1, 1, 1);

        textEdit = new QTextEdit(CrabMultiMediaPlayer);
        textEdit->setObjectName(QString::fromUtf8("textEdit"));

        gridLayout->addWidget(textEdit, 1, 0, 1, 1);

        lineEdit = new QLineEdit(CrabMultiMediaPlayer);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        QSizePolicy sizePolicy3(QSizePolicy::Expanding, QSizePolicy::Preferred);
        sizePolicy3.setHorizontalStretch(0);
        sizePolicy3.setVerticalStretch(0);
        sizePolicy3.setHeightForWidth(lineEdit->sizePolicy().hasHeightForWidth());
        lineEdit->setSizePolicy(sizePolicy3);
        lineEdit->setMinimumSize(QSize(0, 30));
        lineEdit->setMaximumSize(QSize(16777215, 20));
        lineEdit->setFrame(true);
        lineEdit->setClearButtonEnabled(false);

        gridLayout->addWidget(lineEdit, 2, 0, 1, 2);

        gridLayout->setRowStretch(0, 2);
        gridLayout->setRowStretch(1, 7);
        gridLayout->setRowStretch(2, 1);
        gridLayout->setColumnStretch(0, 5);
        gridLayout->setColumnStretch(1, 1);

        retranslateUi(CrabMultiMediaPlayer);

        QMetaObject::connectSlotsByName(CrabMultiMediaPlayer);
    } // setupUi

    void retranslateUi(QWidget *CrabMultiMediaPlayer)
    {
        CrabMultiMediaPlayer->setWindowTitle(QApplication::translate("CrabMultiMediaPlayer", "CrabMultiMediaPlayer", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("CrabMultiMediaPlayer", "TextLabel", 0, QApplication::UnicodeUTF8));
        pushButton->setText(QApplication::translate("CrabMultiMediaPlayer", "PushButton", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class CrabMultiMediaPlayer: public Ui_CrabMultiMediaPlayer {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CRABMULTIMEDIAPLAYER_H
