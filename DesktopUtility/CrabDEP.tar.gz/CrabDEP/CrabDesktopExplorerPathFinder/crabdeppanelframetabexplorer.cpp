#include "crabdeppanelframetabexplorer.h"

CrabDEPPanelFrameTabExplorer::CrabDEPPanelFrameTabExplorer(QWidget *parent) :
    QListView(parent)
{
    m_DirPath = CrabDEP_RootPath;
    m_FileSystemModel = new QFileSystemModel();
    m_FileSystemModel->setRootPath(m_DirPath);
    this->setModel(m_FileSystemModel);
    this->setCurrentDirPath(m_DirPath);
    // this->setSelectionMode(QAbstractItemView::ContiguousSelection);
    connect(this,SIGNAL(activated(QModelIndex)),this,SLOT(openItemSelected(QModelIndex)));
    //connect(this,SIGNAL(doubleClicked(QModelIndex)),this,SLOT(openItemSelected(QModelIndex)));

    //
    // ContextMenu
    //
    QAction *TempAction_ShowInfo = new QAction("Show Info",this);
    this->addAction(TempAction_ShowInfo);
    connect(TempAction_ShowInfo,SIGNAL(triggered()),this,SLOT(actionShowInfo()));
    // connect(this->selectionModel(),SIGNAL(selectionChanged(const QItemSelection &, const QItemSelection &)),
    //        this,SLOT(selectionChanged(const QItemSelection &, const QItemSelection &))); // reference: http://www.qtforum.org/article/35530/qlistview-unselect-item.html

    this->setContextMenuPolicy(Qt::ActionsContextMenu);
}

QFileSystemModel *CrabDEPPanelFrameTabExplorer::currentFileSystemModel()
{
    return m_FileSystemModel;
}

QString CrabDEPPanelFrameTabExplorer::currentDirName()
{
    QDir TempDir(m_DirPath); TempDir.dirName();
    QString TempBaseName = TempDir.dirName();
    if(TempBaseName.isEmpty()) {TempBaseName="ROOT";}
    return TempBaseName;
}

void CrabDEPPanelFrameTabExplorer::setCurrentDirPath(QString DirPath)
{
    m_DirPath = DirPath; if(m_DirPath.isEmpty()) {m_DirPath=CrabDEP_RootPath;}
    // qDebug() << "CrabDEPPanelFrameTabExplorer::setCurrentDirPath()" << m_DirPath;
    this->setRootIndex(m_FileSystemModel->index(m_DirPath));
}






void CrabDEPPanelFrameTabExplorer::openItemSelected(QModelIndex modelindex)
{
    if(m_FileSystemModel) {
        QString CurrentItemPath = m_FileSystemModel->filePath(modelindex);
        qDebug() << "CrabDEPPanelFrameTabExplorer::openItemSelected()" << CurrentItemPath;
        //
        // open file or directory
        //
        QFileInfo CurrentFileInfo(CurrentItemPath);
        if(CurrentFileInfo.isFile()) {
            // open file
            QDesktopServices::openUrl(QUrl::fromLocalFile(CurrentFileInfo.absoluteFilePath()));
        } else if(CurrentFileInfo.isDir()) {
            // open dir
            qDebug() << "CrabDEPPanelFrameTabExplorer::openItemSelected()" << "emit panelFrameTabExplorerChangeDir()";
            emit panelFrameTabExplorerChangeDir(CurrentFileInfo.absoluteFilePath());
        }
    }
}

void CrabDEPPanelFrameTabExplorer::actionShowInfo()
{
    //
    if(m_FileSystemModel) {
        QString TempFileName = m_FileSystemModel->filePath(this->currentIndex());
        qDebug() << "CrabDEPPanelFrameTabExplorer::actionShowInfo()" << "currentIndex()" << this->currentIndex() << TempFileName;
        QFileInfo TempFileInfo(TempFileName);
        if(TempFileInfo.isFile()) {
            QString TempFileSizeStr = convertDirSizeToString(TempFileInfo.size());
            QMessageBox::information(this,tr("Show Info"),"File Name:\n"+TempFileName+"\n"+"File Size:\n"+TempFileSizeStr+"\n",QMessageBox::Ok);
        } else if(TempFileInfo.isDir()) {
            // QMessageBox::information(this,"Show Info","Dir Name:\n"+TempFileName+"\n"+"Dir Size:\n"+"0"+"\n",QMessageBox::Ok);
            //
            // now display ShowInfoWidget
            CrabDEPShowInfoWidget *TempShowInfoWidget = new CrabDEPShowInfoWidget();
            TempShowInfoWidget->addInfo(tr("Dir Name:"),TempFileInfo.fileName());
            TempShowInfoWidget->addInfo(tr("Dir Path:"),TempFileInfo.absolutePath());
            TempShowInfoWidget->addInfo(tr("Dir Item:"),QString("0"));
            TempShowInfoWidget->addInfo(tr("Dir Size:"),QString("0"));
            //
            // now calculate dir size iteratively and update ShowInfoWidget
            getCurrentDirSize(TempFileName,TempShowInfoWidget);
        }
    } else {
        qDebug() << "CrabDEPPanelFrameTabExplorer::actionShowInfo()" << "Error! m_FileSystemModel is invalid!";
    }
}

long CrabDEPPanelFrameTabExplorer::getCurrentDirSize(QString DirPath, CrabDEPShowInfoWidget *ShowInfoWidget)
{
    long TempSize = 0;
    // check input is a dir
    QFileInfo TempFileInfo(DirPath);
    if(TempFileInfo.isDir()) {
        QDir TempDir(DirPath);
        TempDir.setFilter(QDir::Files | QDir::Dirs | QDir::Hidden | QDir::NoSymLinks);
        QFileInfoList TempList = TempDir.entryInfoList();
        // qDebug() << "CrabDEPPanelFrameTabExplorer::getCurrentDirSize()" << "looping" << TempList.count() << "items.";
        for(int i=1; i < TempList.size(); i++) { // <Note> i must start from 1
            QFileInfo TempInfo = TempList.at(i);
            if((TempInfo.fileName() != ".") && (TempInfo.fileName() != "..")) {
                if(TempInfo.isDir()) {
                    qDebug() << "CrabDEPPanelFrameTabExplorer::getCurrentDirSize()" << "looping into" << TempInfo.filePath();
                    TempSize += this->getCurrentDirSize(TempInfo.filePath());
                    QApplication::processEvents();
                    if(ShowInfoWidget) {
                        ShowInfoWidget->setInfo(tr("Dir Item:"),QString::number(TempSize).append(" ").append(tr("Bytes")));
                        ShowInfoWidget->setInfo(tr("Dir Size:"),QString::number(TempSize).append(" ").append(tr("Bytes")));
                    }
                }
                else {
                    TempSize += TempInfo.size();
                    QApplication::processEvents();
                    if(ShowInfoWidget) { ShowInfoWidget->setInfo(tr("Dir Size:"),convertDirSizeToString(TempSize)); }
                }
            }
        }
    } // reference: http://stackoverflow.com/questions/7096637/how-can-i-get-the-file-size-in-directory-traversal
    return TempSize;
}

QString CrabDEPPanelFrameTabExplorer::convertDirSizeToString(long DirSize)
{
    QString DirSizeStr = "";
    QString DirSizeUnit = tr("Bytes");
    if(DirSize>=1024) {
        DirSize = DirSize/1024; DirSizeUnit = tr("KB");
        if(DirSize>=1024) {
            DirSize = DirSize/1024; DirSizeUnit = tr("MB");
            if(DirSize>=1024) {
                DirSize = DirSize/1024; DirSizeUnit = tr("GB");
            }
        }
    }
    DirSizeStr = QString::number(DirSize).append(" ").append(DirSizeUnit);
    return DirSizeStr;
}






void CrabDEPPanelFrameTabExplorer::mousePressEvent(QMouseEvent *event)
{
    //qDebug() << "CrabDEPPanelFrameTabExplorer::mousePressEvent()";

    //
    // check mouse on item or not
    QModelIndex TempItem = indexAt(event->pos());
    if ((TempItem.row()==-1 && TempItem.column()==-1) || selectionModel()->isSelected(indexAt(event->pos()))) {
        clearSelection();
        // const QModelIndex TempIndex;
        // selectionModel()->setCurrentIndex(TempIndex, QItemSelectionModel::Select);
    }

    emit panelFrameTabExplorerActivated();
    QListView::mousePressEvent(event);
}

void CrabDEPPanelFrameTabExplorer::mouseDoubleClickEvent(QMouseEvent *event)
{
    //qDebug() << "CrabDEPPanelFrameTabExplorer::mouseDoubleClickEvent()";
    QListView::mouseDoubleClickEvent(event);
}

void CrabDEPPanelFrameTabExplorer::contextMenuEvent(QContextMenuEvent *event)
{
    qDebug() << "CrabDEPPanelFrameTabExplorer::contextMenuEvent()";
    QListView::contextMenuEvent(event);
}



