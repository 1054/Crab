#include "crabdepmainframe.h"
#include <QApplication>
#include <crabdepglobalvariables.h>






/*
 *
 * 2015-11-04
 *      two panel file explorer
 *      address bar, status bar, two panels
 *      double/single click to change dir
 *
 */

/*
 * 2015-11-16
 *      simple context menu by adding actions
 *      context menu Show Info
 *      <TODO> Ctrl+Up to change dir ..
 */
















int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    CrabDEPMainFrame w;

    w.show();

    return a.exec();
}
