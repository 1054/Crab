#ifndef CRABDEPPANELFRAMETAB_H
#define CRABDEPPANELFRAMETAB_H

#include <QTabWidget>
#include <QPainter>
#include <QListView>
#include <QListWidget>
#include <QFileSystemModel>
#include <QDir>
#include <QDebug>
#include "crabdepglobalvariables.h"
#include "crabdeppanelframetabexplorer.h"


class CrabDEPPanelFrameTab : public QTabWidget
{
    Q_OBJECT
public:
    explicit CrabDEPPanelFrameTab(QWidget *parent = 0);
    bool isCurrentPanelFrameTab();
    bool isCurrentPanelFrameTabActive();
    void setCurrentPanelFrameTab(bool IsCurrentActiveTab = true);
    void setCurrentPanelFrameTabActive(bool IsCurrentActiveTab = true);
    void addCurrentPanelFrameTabExplorer(QString NewPath = QString());
    void removeCurrentPanelFrameTabExplorer();
    void removeAllPanelFrameTabExplorers();
    QString currentDirPath();

signals:
    void panelFrameTabClicked();
    void panelFrameTabChanged(QString DirPath);

public slots:
    void currentPanelFrameTabActivated();
    void currentPanelFrameTabChangeDir(QString DirPath);
    void updateCurrentPath(QString NewPath = QString());

protected:
    void mousePressEvent(QMouseEvent *event);
    void mouseMoveEvent(QMouseEvent *event);
    void paintEvent(QPaintEvent *event);

private:
    QString m_DirPath;
    bool m_IsCurrentTab;

};

#endif // CRABDEPPANELFRAMETAB_H
