#ifndef CRABDEPMAINFRAME_H
#define CRABDEPMAINFRAME_H

#include <QWidget>
#include <QDebug>
#include "crabdeppanelframetab.h"

namespace Ui {
class CrabDEPMainFrame;
}

class CrabDEPMainFrame : public QWidget
{
    Q_OBJECT

public:
    explicit CrabDEPMainFrame(QWidget *parent = 0);
    ~CrabDEPMainFrame();

public slots:
    void activatePanelFrameTab();

private:
    Ui::CrabDEPMainFrame *ui;
};

#endif // CRABDEPMAINFRAME_H
