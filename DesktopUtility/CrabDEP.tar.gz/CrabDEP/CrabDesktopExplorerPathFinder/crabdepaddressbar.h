#ifndef CRABDEPADDRESSBAR_H
#define CRABDEPADDRESSBAR_H

#include <QWidget>
#include <QPainter>
#include <QHBoxLayout>
#include <QPushButton>
#include <QFontMetrics>
#include <QHostInfo>
#include <QPainter>
#include "crabdepglobalvariables.h"


extern QString CrabDEP_CurrentPath;

class CrabDEPAddressBar : public QWidget
{
    Q_OBJECT
public:
    explicit CrabDEPAddressBar(QWidget *parent = 0);

signals:
    void updateCurrentPath(QString NewPath);

public slots:
    void addressBarButtonClicked();
    void updateAddressBar(QString InputPath = QString());

protected:
    void paintEvent(QPaintEvent *event);

private:
    QHBoxLayout *m_Layout;
    QString m_DirPath;

};

#endif // CRABDEPADDRESSBAR_H
