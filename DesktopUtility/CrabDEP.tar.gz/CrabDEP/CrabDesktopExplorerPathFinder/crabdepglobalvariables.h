//#ifndef CRABDEPGLOBALVARIABLES_H
//#define CRABDEPGLOBALVARIABLES_H

#include <QtGlobal>
#include <QString>
#include <QDebug>

extern QString CrabDEP_CurrentPath;
extern QString CrabDEP_RootPath;
extern QString CrabDEP_PathSep;

//#endif // CRABDEPGLOBALVARIABLES_H


