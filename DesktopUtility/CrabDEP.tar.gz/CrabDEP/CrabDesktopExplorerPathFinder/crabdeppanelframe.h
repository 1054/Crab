#ifndef CRABDEPPANELFRAME_H
#define CRABDEPPANELFRAME_H

#include <QWidget>
#include <QPainter>
#include <QTabWidget>
#include <QMouseEvent>
#include <QDebug>
#include "crabdepglobalvariables.h"
#include "crabdeppanelframetab.h"

class CrabDEPPanelFrame : public QWidget
{
    Q_OBJECT
public:
    explicit CrabDEPPanelFrame(QWidget *parent = 0);
    CrabDEPPanelFrameTab *currentPanelFrameTab();
    void setCurrentPanelFrameTab(QTabWidget *NewTabWidget);
    void setCurrentTabWidget(QTabWidget *NewTabWidget);
    void removeCurrentPanelFrameTab();
    void removeAllPanelFrameTab();

signals:

public slots:
    void updateCurrentPath(QString NewPath);

protected:
    void mousePressEvent(QMouseEvent *event);
    void paintEvent(QPaintEvent *event);

private:
    CrabDEPPanelFrameTab *m_TabWidget;
    QString m_DirPath;

};

#endif // CRABDEPPANELFRAME_H
