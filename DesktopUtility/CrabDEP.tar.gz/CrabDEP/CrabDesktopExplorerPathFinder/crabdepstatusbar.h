#ifndef CRABDEPSTATUSBAR_H
#define CRABDEPSTATUSBAR_H

#include <QWidget>
#include <QPainter>
#include "crabdepglobalvariables.h"


class CrabDEPStatusBar : public QWidget
{
    Q_OBJECT
public:
    explicit CrabDEPStatusBar(QWidget *parent = 0);

signals:

public slots:
    void updateStatusBar(QString InputPath = QString());

protected:
    void paintEvent(QPaintEvent *event);

private:
    QString m_DirPath;

};

#endif // CRABDEPSTATUSBAR_H
