#include "crabdepaddressbar.h"
#include "crabdepaddressbarbutton.h"


CrabDEPAddressBar::CrabDEPAddressBar(QWidget *parent) :
    QWidget(parent)
{
    m_Layout = new QHBoxLayout(this);
    m_DirPath = "";
    updateAddressBar();
}

void CrabDEPAddressBar::addressBarButtonClicked()
{
    CrabDEPAddressBarButton* TempButton = (CrabDEPAddressBarButton*)sender();
    CrabDEP_CurrentPath = TempButton->dirPath();
    m_DirPath = TempButton->dirPath();
    emit updateCurrentPath(m_DirPath);
    // updateAddressBar(CrabDEP_CurrentPath);
}

void CrabDEPAddressBar::updateAddressBar(QString InputPath)
{
    // Check input
    QString UpdatePath = "/";
    if(InputPath.isEmpty()) {
        if(CrabDEP_CurrentPath.isEmpty()) {
            qDebug() << "CrabDEPAddressBar::updateAddressBar() Input string is empty! Update as root path!";
        } else {
            UpdatePath = CrabDEP_CurrentPath;
        }
    } else {
        UpdatePath = InputPath;
    }
    m_DirPath = UpdatePath;
    qDebug() << "CrabDEPAddressBar::updateAddressBar()" << m_DirPath;
    // Clean items
    QLayoutItem* TempItem;
    while((TempItem=m_Layout->takeAt(0))!=NULL) {
        delete TempItem->widget(); delete TempItem;
    }
    // Add items
    // CrabDEPAddressBarButton *TempButtonA = new CrabDEPAddressBarButton(QHostInfo::localHostName()); TempButtonA->setEnabled(false);
    // m_Layout->addWidget(TempButtonA);
    CrabDEPAddressBarButton *TempButtonB = new CrabDEPAddressBarButton(" "); TempButtonB->setEnabled(false);
    m_Layout->addWidget(TempButtonB);
    QStringList TempStringList = UpdatePath.split("/",QString::SkipEmptyParts); TempStringList.prepend("/");
    QStringList TempStringList2; TempStringList2.clear();
    while(TempStringList.count()>0) {
        if(!TempStringList.first().isEmpty()) {
            TempStringList2.append(TempStringList.first());
            CrabDEPAddressBarButton *TempButton = new CrabDEPAddressBarButton(TempStringList2);
            connect(TempButton,SIGNAL(clicked()),this,SLOT(addressBarButtonClicked()));
            m_Layout->addWidget(TempButton);
        }
        TempStringList.removeFirst();
    }
//    for(int i=0; i<TempStringList.count(); i++) {
//        if(i==0 || !TempStringList.first().isEmpty()) {
//            CrabDEPAddressBarButton *TempButton = new CrabDEPAddressBarButton(TempStringList);
//            m_Layout->insertWidget(0,TempButton);
//            //m_Layout->addWidget(TempButton);
//        }
//    }
    m_Layout->addStretch();
    m_Layout->setSpacing(0);
    // Update view
    update();
    // Send signal if needed
    if(sender()) {
        qDebug() << "CrabDEPAddressBar::updateAddressBar()" << "sender" << sender()->objectName();
        if(sender()->objectName()=="tabL" || sender()->objectName()=="tabR") {
            emit updateCurrentPath(m_DirPath);
        }
    } else {
        emit updateCurrentPath(m_DirPath);
    }
}

void CrabDEPAddressBar::paintEvent(QPaintEvent *event)
{
    // Create painter
    QPainter TempPainter(this);
    TempPainter.setPen(QColor(172,172,172));
    // Draw widget broder
    if(1==1) {
        TempPainter.drawRoundedRect(QRect(0,0,this->width()-2,this->height()-2), 5.0, 5.0);
    }
    // Default paintEvent()
    QWidget::paintEvent(event);
}
