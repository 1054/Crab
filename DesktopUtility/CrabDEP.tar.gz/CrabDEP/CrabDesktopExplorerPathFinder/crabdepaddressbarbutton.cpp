#include "crabdepaddressbarbutton.h"

CrabDEPAddressBarButton::CrabDEPAddressBarButton(QWidget *parent) :
    QPushButton(parent)
{
    (void)parent;
}

CrabDEPAddressBarButton::CrabDEPAddressBarButton(const QString &text, QWidget *parent)
{
    (void)parent;
    m_DirPaths.clear(); m_DirPaths.append(text);
    this->setText(text);
    setAddressBarButtonStyle();
    connect(this,SIGNAL(clicked()),this,SLOT(addressBarButtonClicked()));
}

CrabDEPAddressBarButton::CrabDEPAddressBarButton(QStringList &dirpaths, QWidget *parent)
{
    (void)parent; m_DirPaths = dirpaths;
    QString text = this->dirName();
    this->setText(text);
    setAddressBarButtonStyle();
    connect(this,SIGNAL(clicked()),this,SLOT(addressBarButtonClicked()));
}

void CrabDEPAddressBarButton::setAddressBarButtonStyle()
{
    QFontMetrics TempFontMetrics(this->font());
    // measure the text width with QFontMetrics
    // and set the text width as the button width
    int TempTextWidth = TempFontMetrics.width(this->text());
    this->setFixedWidth(TempTextWidth);
    this->setFlat(true);
    this->setStyleSheet(QString("QPushButton:hover{background-color:rgba(46,139,87,50); border:none;}\n")+
                        QString("QPushButton:default{border:none;}\n")+
                        QString("QPushButton:checked{border:none;}\n"));
    // To improve the stylesheet of QPushButton, we have wrote the stylesheet into crabdepmainframe.ui (ui->addressBar)
    // Note that when setting background-color, we must also set border 0. see http://doc.qt.io/qt-4.8/stylesheet-reference.html
}

QStringList CrabDEPAddressBarButton::dirPaths()
{
    return m_DirPaths;
}

QString CrabDEPAddressBarButton::dirPath()
{
    QStringList TempDirPaths = m_DirPaths;
    QString TempDirPath = "";
    if(m_DirPaths.count()==1 && m_DirPaths.first()=="/") {
        TempDirPath = TempDirPaths.first();
    } else {
        TempDirPaths.removeFirst();
        TempDirPath = CrabDEP_PathSep+TempDirPaths.join(CrabDEP_PathSep)+CrabDEP_PathSep;
    }
    return TempDirPath;
}

QString CrabDEPAddressBarButton::dirName()
{
    QString TempDirName = "";
    if(m_DirPaths.count()==1 && m_DirPaths.first()=="/") {
        TempDirName = m_DirPaths.last(); // root path
    } else if(m_DirPaths.count()>=1) {
        TempDirName = m_DirPaths.last()+"/";
    }
    return TempDirName;
}

void CrabDEPAddressBarButton::addressBarButtonClicked()
{
    qDebug() << "CrabDEPAddressBarButton::addressBarButtonClicked()" << this->dirPath();
}

void CrabDEPAddressBarButton::mouseReleaseEvent(QMouseEvent *event)
{
    QPushButton::mouseReleaseEvent(event);
}
