#include "crabdeppanelframetab.h"

CrabDEPPanelFrameTab::CrabDEPPanelFrameTab(QWidget *parent) :
    QTabWidget(parent)
{
    m_DirPath = CrabDEP_RootPath;
    m_IsCurrentTab = true;
    connect(this,SIGNAL(currentChanged(int)),this,SLOT(currentPanelFrameTabActivated()));
    //removeAllPanelFrameTabExplorers(); // at this time the tabs are not ready yet!
    //addCurrentPanelFrameTabExplorer(m_DirPath);
    //updateCurrentPath();
}

bool CrabDEPPanelFrameTab::isCurrentPanelFrameTab()
{
    return isCurrentPanelFrameTabActive();
}

bool CrabDEPPanelFrameTab::isCurrentPanelFrameTabActive()
{
    return m_IsCurrentTab;
}

void CrabDEPPanelFrameTab::setCurrentPanelFrameTab(bool IsCurrentActiveTab)
{
    setCurrentPanelFrameTabActive(IsCurrentActiveTab);
}

void CrabDEPPanelFrameTab::setCurrentPanelFrameTabActive(bool IsCurrentActiveTab)
{
    // qDebug() << "CrabDEPPanelFrameTab::setCurrentPanelFrameTabActive()" << this->objectName() << "is active?" << this->isCurrentPanelFrameTabActive();
    m_IsCurrentTab = IsCurrentActiveTab;
    // update();
}

void CrabDEPPanelFrameTab::addCurrentPanelFrameTabExplorer(QString NewPath)
{
    qDebug() << "CrabDEPPanelFrameTab::addCurrentPanelFrameTabExplorer()";
    if(1) {
        m_DirPath = NewPath; if(m_DirPath.isEmpty()) {m_DirPath=CrabDEP_RootPath;}
        qDebug() << "CrabDEPPanelFrameTab::addCurrentPanelFrameTabExplorer()" << m_DirPath;
        CrabDEPPanelFrameTabExplorer *TempExplorer = new CrabDEPPanelFrameTabExplorer(this);
        TempExplorer->setCurrentDirPath(m_DirPath);
        this->addTab(TempExplorer,TempExplorer->currentDirName());
        this->setCurrentWidget(TempExplorer);
        connect(TempExplorer,SIGNAL(pressed(QModelIndex)),this,SLOT(currentPanelFrameTabActivated())); // when TabWidget activated
        connect(TempExplorer,SIGNAL(panelFrameTabExplorerActivated()),this,SLOT(currentPanelFrameTabActivated())); // when TabWidget->Explorer activated
        connect(TempExplorer,SIGNAL(panelFrameTabExplorerChangeDir(QString)),this,SLOT(currentPanelFrameTabChangeDir(QString))); // when ChangeDir
    }
}
void CrabDEPPanelFrameTab::removeCurrentPanelFrameTabExplorer()
{
    if(this->currentWidget()) {
        this->removeTab(this->currentIndex());
    }
}

void CrabDEPPanelFrameTab::removeAllPanelFrameTabExplorers()
{
    // qDebug() << "CrabDEPPanelFrameTab::removeAllPanelFrameTabExplorers()" << "count" << this->count();
    while(this->count()>0) {this->removeTab(this->currentIndex());}
    // qDebug() << "CrabDEPPanelFrameTab::removeAllPanelFrameTabExplorers()" << "count" << this->count();
}

void CrabDEPPanelFrameTab::updateCurrentPath(QString NewPath)
{
    // qDebug() << "CrabDEPPanelFrameTab::updateCurrentPath()" << this->objectName() << "is active?" << this->isCurrentPanelFrameTabActive();
    if(this->isCurrentPanelFrameTabActive()) {
        if(this->count()>0) {
            // if(this->count()==0) {addCurrentPanelFrameTabExplorer(m_DirPath);}
            m_DirPath = NewPath; if(m_DirPath.isEmpty()) {m_DirPath=CrabDEP_RootPath;}
            // qDebug() << "CrabDEPPanelFrameTab::updateCurrentPath()" << this->objectName() << "is active?" << this->isCurrentPanelFrameTabActive() << NewPath;
            CrabDEPPanelFrameTabExplorer *TempExplorer = (CrabDEPPanelFrameTabExplorer *)(this->currentWidget());
            TempExplorer->setCurrentDirPath(m_DirPath);
            this->setTabText(this->currentIndex(),TempExplorer->currentDirName());
            // qDebug() << "CrabDEPPanelFrameTab::updateCurrentPath()" << this->objectName() << "is active?" << this->isCurrentPanelFrameTabActive() << NewPath << "tab" << TempExplorer->currentDirName();
        }
    }
}

QString CrabDEPPanelFrameTab::currentDirPath()
{
    return m_DirPath;
}

void CrabDEPPanelFrameTab::currentPanelFrameTabActivated()
{
    // qDebug() << "CrabDEPPanelFrameTab::currentPanelFrameTabActivated()";
    if(!this->isCurrentPanelFrameTabActive()) {emit panelFrameTabClicked();}
}

void CrabDEPPanelFrameTab::currentPanelFrameTabChangeDir(QString DirPath)
{
    qDebug() << "CrabDEPPanelFrameTab::currentPanelFrameTabChangeDir()";
    if(this->isCurrentPanelFrameTabActive()) {
        qDebug() << "CrabDEPPanelFrameTab::currentPanelFrameTabChangeDir()" << "emit panelFrameTabChanged()";
        emit panelFrameTabChanged(DirPath);
    }
}

void CrabDEPPanelFrameTab::mousePressEvent(QMouseEvent *event)
{
    // qDebug() << "CrabDEPPanelFrameTab::mousePressEvent()";
    if(!this->isCurrentPanelFrameTabActive()) {emit panelFrameTabClicked();}
    QTabWidget::mousePressEvent(event);
}

void CrabDEPPanelFrameTab::mouseMoveEvent(QMouseEvent *event)
{
    QTabWidget::mouseMoveEvent(event);
}

void CrabDEPPanelFrameTab::paintEvent(QPaintEvent *event)
{
    // Create painter
    QPainter TempPainter(this);
    // Draw widget broder
    if(isCurrentPanelFrameTabActive()) {
        TempPainter.setPen(QColor(46,139,87,50));
        TempPainter.drawRoundedRect(QRect(0,0,this->width()-2,this->height()-2), 5.0, 5.0);
    }
    // Default paintEvent()
    QTabWidget::paintEvent(event);
}


