#include "crabdepmainframe.h"
#include "ui_crabdepmainframe.h"


CrabDEPMainFrame::CrabDEPMainFrame(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::CrabDEPMainFrame)
{
    ui->setupUi(this);

    CrabDEP_CurrentPath = "/home/dzliu/Code/Crab/CrabDEP/test-1/";

//    ui->addressBar->updateAddressBar();
//    ui->statusBar->updateStatusBar();
    ui->tabL->removeAllPanelFrameTabExplorers();
    ui->tabR->removeAllPanelFrameTabExplorers();
    ui->tabL->addCurrentPanelFrameTabExplorer(CrabDEP_CurrentPath);
    ui->tabR->addCurrentPanelFrameTabExplorer(CrabDEP_CurrentPath);

    //ui->panelLeft->setCurrentTabWidget(ui->tabL);
    //ui->panelRight->setCurrentTabWidget(ui->tabR);
    ui->tabL->setCurrentPanelFrameTabActive(true);
    ui->tabR->setCurrentPanelFrameTabActive(false);
    connect(ui->addressBar,SIGNAL(updateCurrentPath(QString)),ui->tabL,SLOT(updateCurrentPath(QString)));
    connect(ui->addressBar,SIGNAL(updateCurrentPath(QString)),ui->tabR,SLOT(updateCurrentPath(QString)));
    connect(ui->addressBar,SIGNAL(updateCurrentPath(QString)),ui->statusBar,SLOT(updateStatusBar(QString)));
    connect(ui->tabL,SIGNAL(panelFrameTabClicked()),this,SLOT(activatePanelFrameTab()));
    connect(ui->tabR,SIGNAL(panelFrameTabClicked()),this,SLOT(activatePanelFrameTab()));
    connect(ui->tabL,SIGNAL(panelFrameTabChanged(QString)),ui->addressBar,SLOT(updateAddressBar(QString)));
    connect(ui->tabR,SIGNAL(panelFrameTabChanged(QString)),ui->addressBar,SLOT(updateAddressBar(QString)));

    ui->addressBar->updateAddressBar(CrabDEP_CurrentPath);
}

void CrabDEPMainFrame::activatePanelFrameTab()
{
    CrabDEPPanelFrameTab *TempTab = (CrabDEPPanelFrameTab *)sender();
    qDebug() << "CrabDEPMainFrame::activatePanelFrameTab()" << TempTab->objectName();
    if(TempTab->objectName()=="tabL") {ui->tabL->setCurrentPanelFrameTabActive(true);ui->tabR->setCurrentPanelFrameTabActive(false);ui->addressBar->updateAddressBar(ui->tabL->currentDirPath());}
    if(TempTab->objectName()=="tabR") {ui->tabL->setCurrentPanelFrameTabActive(false);ui->tabR->setCurrentPanelFrameTabActive(true);ui->addressBar->updateAddressBar(ui->tabR->currentDirPath());}
    update();
}

CrabDEPMainFrame::~CrabDEPMainFrame()
{
    delete ui;
}
