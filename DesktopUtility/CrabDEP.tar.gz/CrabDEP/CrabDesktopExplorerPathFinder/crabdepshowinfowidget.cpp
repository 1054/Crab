#include "crabdepshowinfowidget.h"

CrabDEPShowInfoWidget::CrabDEPShowInfoWidget(QWidget *parent) :
    QWidget(parent)
{
    m_Layout = new QVBoxLayout();

    m_Layout->addStretch();

    m_ButtonES = new QPushButton(tr("Edit"));
    m_Layout->addWidget(m_ButtonES);
    connect(m_ButtonES,SIGNAL(clicked()),this,SLOT(goEditOrSave()));

    m_ButtonOK = new QPushButton(tr("OK"));
    m_Layout->addWidget(m_ButtonOK);
    connect(m_ButtonOK,SIGNAL(clicked()),this,SLOT(close()));

    this->setLayout(m_Layout);
    this->setMinimumSize(QSize(420,560));
    this->show();
}

void CrabDEPShowInfoWidget::addInfo(QString InfoName, QString InfoText)
{
    QHBoxLayout *NewLayout = new QHBoxLayout();
    QLabel *NewLabel = new QLabel(InfoName); NewLabel->setMinimumWidth(90); NewLabel->setStyleSheet("border-style:outset;border-width:2px;border-radius:5px;border-color:grey;");
    QLineEdit *NewLineEdit = new QLineEdit(InfoText); NewLineEdit->setReadOnly(true);
    NewLayout->addWidget(NewLabel);
    NewLayout->addWidget(NewLineEdit);
    m_Layout->insertLayout(m_Layout->count()-3,NewLayout); // <TODO> 3 last item should be at the last positions
    //m_Layout->insertWidget(m_Layout->count()-2,);
}

void CrabDEPShowInfoWidget::setInfo(QString InfoName, QString InfoText)
{
    // find a info item and change its text
    foreach(QHBoxLayout *TempLayout, m_Layout->findChildren<QHBoxLayout *>()) {
        if(TempLayout) {
            // qDebug() << "CrabDEPShowInfoWidget::goEditOrSave()" << TempLayout->count();
            if(TempLayout->count()==2) {
                QLabel *TempLabel = (QLabel *)TempLayout->itemAt(0)->widget(); // qobject_cast<QLineEdit *>(object)
                QLineEdit *TempLineEdit = (QLineEdit *)TempLayout->itemAt(1)->widget();
                // qDebug() << "CrabDEPShowInfoWidget::goEditOrSave()" << TempLabel << TempLineEdit;
                if(TempLabel && TempLineEdit) {
                    if(TempLabel->text() == InfoName) {
                        TempLineEdit->setText(InfoText);
                    }
                }
            }
        }
    }
}

void CrabDEPShowInfoWidget::goEditOrSave()
{
    // toggle edit state or save state

    if(m_ButtonES->text()==tr("Edit")) {
        foreach(QHBoxLayout *TempLayout, m_Layout->findChildren<QHBoxLayout *>()) {
            if(TempLayout) {
                // qDebug() << "CrabDEPShowInfoWidget::goEditOrSave()" << TempLayout->count();
                if(TempLayout->count()==2) {
                    QLabel *TempLabel = (QLabel *)TempLayout->itemAt(0)->widget(); // qobject_cast<QLineEdit *>(object)
                    QLineEdit *TempLineEdit = (QLineEdit *)TempLayout->itemAt(1)->widget();
                    // qDebug() << "CrabDEPShowInfoWidget::goEditOrSave()" << TempLabel << TempLineEdit;
                    if(TempLabel && TempLineEdit) {
                        if(TempLabel->text().contains(tr("Dir Name"))) {
                            TempLineEdit->setReadOnly(false); TempLineEdit->setStyleSheet("background:rgba(254,254,254,250);");
                        }
                    }
                }
            }
        }
        m_ButtonES->setText(tr("Save"));
    }
    else if(m_ButtonES->text()==tr("Save")) {
        foreach(QHBoxLayout *TempLayout, m_Layout->findChildren<QHBoxLayout *>()) {
            if(TempLayout) {
                // qDebug() << "CrabDEPShowInfoWidget::goEditOrSave()" << TempLayout->count();
                if(TempLayout->count()==2) {
                    QLabel *TempLabel = (QLabel *)TempLayout->itemAt(0)->widget(); // qobject_cast<QLineEdit *>(object)
                    QLineEdit *TempLineEdit = (QLineEdit *)TempLayout->itemAt(1)->widget();
                    // qDebug() << "CrabDEPShowInfoWidget::goEditOrSave()" << TempLabel << TempLineEdit;
                    if(TempLabel && TempLineEdit) {
                        if(TempLabel->text().contains(tr("Dir Name"))) {
                            TempLineEdit->setReadOnly(true); TempLineEdit->setStyleSheet("");
                        }
                    }
                }
            }
        }
        m_ButtonES->setText(tr("Edit"));
    }
}
