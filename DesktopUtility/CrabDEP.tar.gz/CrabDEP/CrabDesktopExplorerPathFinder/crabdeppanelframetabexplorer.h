#ifndef CRABDEPPANELFRAMETABEXPLORER_H
#define CRABDEPPANELFRAMETABEXPLORER_H

#include <QListView>
#include <QFileSystemModel>
#include <QFileInfo>
#include <QModelIndex>
#include <QMouseEvent>
#include <QContextMenuEvent>
#include <QDesktopServices>
#include <QUrl>
#include <QAction>
#include <QMessageBox>
#include <QApplication>
#include <QDebug>
#include "crabdepshowinfowidget.h"
#include "crabdepglobalvariables.h"


class CrabDEPPanelFrameTabExplorer : public QListView
{
    Q_OBJECT
public:
    explicit CrabDEPPanelFrameTabExplorer(QWidget *parent = 0);
    QFileSystemModel *currentFileSystemModel();
    QString currentDirName();
    void setCurrentDirPath(QString DirPath);
    long getCurrentDirSize(QString DirPath, CrabDEPShowInfoWidget *ShowInfoWidget = NULL);
    QString convertDirSizeToString(long DirSize);

signals:
    void panelFrameTabExplorerActivated();
    void panelFrameTabExplorerChangeDir(QString DirPath);

public slots:
    void openItemSelected(QModelIndex modelindex);
    void actionShowInfo();

protected:
    void mousePressEvent(QMouseEvent *event);
    void mouseDoubleClickEvent(QMouseEvent *event);
    void contextMenuEvent(QContextMenuEvent *event);

private:
    QFileSystemModel *m_FileSystemModel;
    QString m_DirPath;

};

#endif // CRABDEPPANELFRAMETABEXPLORER_H
