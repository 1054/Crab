#ifndef CRABDEPADDRESSBARBUTTON_H
#define CRABDEPADDRESSBARBUTTON_H

#include <QPushButton>
#include <QFontMetrics>
#include <QPushButton>
#include <QMouseEvent>
#include <QStringList>
#include <QDebug>
#include "crabdepglobalvariables.h"


class CrabDEPAddressBarButton : public QPushButton
{
    Q_OBJECT
public:
    explicit CrabDEPAddressBarButton(QWidget *parent = 0);
    CrabDEPAddressBarButton(const QString &text, QWidget *parent = 0);
    CrabDEPAddressBarButton(QStringList &dirpaths, QWidget *parent = 0);
    void setAddressBarButtonStyle();
    QStringList dirPaths();
    QString dirPath();
    QString dirName();

signals:


public slots:
    void addressBarButtonClicked();

protected:
    void mouseReleaseEvent(QMouseEvent *event);

private:
    QStringList m_DirPaths;


};

#endif // CRABDEPADDRESSBARBUTTON_H
