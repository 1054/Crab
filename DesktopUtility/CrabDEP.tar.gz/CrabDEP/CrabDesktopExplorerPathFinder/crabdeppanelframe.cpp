#include "crabdeppanelframe.h"
#include "crabdeppanelframetab.h"

CrabDEPPanelFrame::CrabDEPPanelFrame(QWidget *parent) :
    QWidget(parent)
{
}

CrabDEPPanelFrameTab *CrabDEPPanelFrame::currentPanelFrameTab()
{
    return m_TabWidget;
}

void CrabDEPPanelFrame::setCurrentPanelFrameTab(QTabWidget *NewTabWidget)
{
    m_TabWidget = (CrabDEPPanelFrameTab *)NewTabWidget;
}

void CrabDEPPanelFrame::setCurrentTabWidget(QTabWidget *NewTabWidget)
{
    m_TabWidget = (CrabDEPPanelFrameTab *)NewTabWidget;
}

void CrabDEPPanelFrame::removeCurrentPanelFrameTab()
{
    //
}

void CrabDEPPanelFrame::removeAllPanelFrameTab()
{
    //
}

void CrabDEPPanelFrame::updateCurrentPath(QString NewPath)
{
    qDebug() << "CrabDEPPanelFrame::updateCurrentPath()" << this->objectName() << "is active?" << this->isEnabled();
    if(this->isEnabled()) {
        if(m_DirPath!=NewPath) {
            m_DirPath = NewPath;
            // we are now dealing with the updateCurrentPath in PanelFrameTab class
        }
    }
}


void CrabDEPPanelFrame::mousePressEvent(QMouseEvent *event)
{
    qDebug() << "CrabDEPPanelFrame::mousePressEvent()";
    QWidget::mousePressEvent(event);
}

void CrabDEPPanelFrame::paintEvent(QPaintEvent *event)
{
    // Create painter
    QPainter TempPainter(this);
    // Draw widget broder
    if(this->currentPanelFrameTab()->isCurrentPanelFrameTab()) {
        TempPainter.setPen(QColor(46,139,87,50));
        TempPainter.drawRoundedRect(QRect(0,0,this->width()-2,this->height()-2), 5.0, 5.0);
    }
    // Default paintEvent()
    QWidget::paintEvent(event);
}


