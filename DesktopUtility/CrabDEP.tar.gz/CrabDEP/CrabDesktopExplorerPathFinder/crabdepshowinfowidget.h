#ifndef CRABDEPSHOWINFOWIDGET_H
#define CRABDEPSHOWINFOWIDGET_H

#include <QWidget>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QPushButton>
#include <QLabel>
#include <QLineEdit>
#include <QObject>
#include <QDebug>

class CrabDEPShowInfoWidget : public QWidget
{
    Q_OBJECT
public:
    explicit CrabDEPShowInfoWidget(QWidget *parent = 0);
    void addInfo(QString InfoName, QString InfoText);
    void setInfo(QString InfoName, QString InfoText);

signals:

public slots:
    void goEditOrSave();

private:
    QVBoxLayout *m_Layout;
    QPushButton *m_ButtonES;
    QPushButton *m_ButtonOK;

};

#endif // CRABDEPSHOWINFOWIDGET_H
