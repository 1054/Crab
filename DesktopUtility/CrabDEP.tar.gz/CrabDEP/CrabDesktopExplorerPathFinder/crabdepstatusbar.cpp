#include "crabdepstatusbar.h"

CrabDEPStatusBar::CrabDEPStatusBar(QWidget *parent) :
    QWidget(parent)
{
    m_DirPath = "";
    updateStatusBar();
}

void CrabDEPStatusBar::updateStatusBar(QString InputPath)
{
    // Check input
    QString UpdatePath = "/";
    if(InputPath.isEmpty()) {
        if(CrabDEP_CurrentPath.isEmpty()) {
            qDebug() << "CrabDEPStatusBar::updateStatusBar() Input string is empty! Update as root path!";
        } else {
            UpdatePath = CrabDEP_CurrentPath;
        }
    } else {
        UpdatePath = InputPath;
    }
    qDebug() << "CrabDEPStatusBar::updateStatusBar()" << UpdatePath;
    m_DirPath = UpdatePath;
    update();
}

void CrabDEPStatusBar::paintEvent(QPaintEvent *event)
{
    // Create painter
    QPainter TempPainter(this);
    TempPainter.setPen(QColor(172,172,172));
    // Draw current path
    if(1==1) {
        TempPainter.drawText(QRect(5.0,0,this->width()-5.0,this->height()-5.0), Qt::AlignLeft|Qt::AlignVCenter, m_DirPath);
    }
    // Draw widget broder
    if(1==1) {
        TempPainter.drawRoundedRect(QRect(0,0,this->width()-2,this->height()-2), 5.0, 5.0);
    }
    // Default paintEvent()
    QWidget::paintEvent(event);
}
