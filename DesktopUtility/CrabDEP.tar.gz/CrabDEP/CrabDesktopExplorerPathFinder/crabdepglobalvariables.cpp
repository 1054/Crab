#include "crabdepglobalvariables.h"


QString CrabDEP_CurrentPath;

QString CrabDEP_PathSep = "/";

QString CrabDEP_RootPath = "/";

//#ifdef Q_OS_LINUX
//CrabDEP_PathSep = "/";
//#endif
//#ifdef Q_OS_MAC
//CrabDEP_PathSep = "/";
//#endif
//#ifdef Q_OS_WIN
//CrabDEP_PathSep = "\\";
//#endif


