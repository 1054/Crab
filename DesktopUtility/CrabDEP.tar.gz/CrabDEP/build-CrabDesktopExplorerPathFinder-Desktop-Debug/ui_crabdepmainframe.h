/********************************************************************************
** Form generated from reading UI file 'crabdepmainframe.ui'
**
** Created by: Qt User Interface Compiler version 4.8.5
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CRABDEPMAINFRAME_H
#define UI_CRABDEPMAINFRAME_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>
#include "crabdepaddressbar.h"
#include "crabdeppanelframetab.h"
#include "crabdepstatusbar.h"

QT_BEGIN_NAMESPACE

class Ui_CrabDEPMainFrame
{
public:
    QVBoxLayout *verticalLayout_3;
    CrabDEPAddressBar *addressBar;
    QHBoxLayout *horizontalLayout;
    QWidget *panelLeft;
    QVBoxLayout *verticalLayout;
    CrabDEPPanelFrameTab *tabL;
    QWidget *tabL_1;
    QWidget *tabL_2;
    QWidget *panelRight;
    QVBoxLayout *verticalLayout_2;
    CrabDEPPanelFrameTab *tabR;
    QWidget *tabR_1;
    QWidget *tabR_2;
    CrabDEPStatusBar *statusBar;

    void setupUi(QWidget *CrabDEPMainFrame)
    {
        if (CrabDEPMainFrame->objectName().isEmpty())
            CrabDEPMainFrame->setObjectName(QString::fromUtf8("CrabDEPMainFrame"));
        CrabDEPMainFrame->resize(800, 600);
        verticalLayout_3 = new QVBoxLayout(CrabDEPMainFrame);
        verticalLayout_3->setSpacing(2);
        verticalLayout_3->setContentsMargins(11, 11, 11, 11);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        verticalLayout_3->setContentsMargins(5, 2, 5, 2);
        addressBar = new CrabDEPAddressBar(CrabDEPMainFrame);
        addressBar->setObjectName(QString::fromUtf8("addressBar"));
        addressBar->setMinimumSize(QSize(0, 36));
        addressBar->setMaximumSize(QSize(16777215, 36));
        addressBar->setMouseTracking(true);
        addressBar->setAcceptDrops(true);
        addressBar->setAutoFillBackground(false);
        addressBar->setStyleSheet(QString::fromUtf8(""));

        verticalLayout_3->addWidget(addressBar);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        panelLeft = new QWidget(CrabDEPMainFrame);
        panelLeft->setObjectName(QString::fromUtf8("panelLeft"));
        verticalLayout = new QVBoxLayout(panelLeft);
        verticalLayout->setSpacing(1);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(1, 1, 1, 1);
        tabL = new CrabDEPPanelFrameTab(panelLeft);
        tabL->setObjectName(QString::fromUtf8("tabL"));
        tabL->setTabsClosable(true);
        tabL->setMovable(true);
        tabL_1 = new QWidget();
        tabL_1->setObjectName(QString::fromUtf8("tabL_1"));
        tabL->addTab(tabL_1, QString());
        tabL_2 = new QWidget();
        tabL_2->setObjectName(QString::fromUtf8("tabL_2"));
        tabL->addTab(tabL_2, QString());

        verticalLayout->addWidget(tabL);


        horizontalLayout->addWidget(panelLeft);

        panelRight = new QWidget(CrabDEPMainFrame);
        panelRight->setObjectName(QString::fromUtf8("panelRight"));
        verticalLayout_2 = new QVBoxLayout(panelRight);
        verticalLayout_2->setSpacing(1);
        verticalLayout_2->setContentsMargins(11, 11, 11, 11);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(1, 1, 1, 1);
        tabR = new CrabDEPPanelFrameTab(panelRight);
        tabR->setObjectName(QString::fromUtf8("tabR"));
        tabR->setTabsClosable(true);
        tabR->setMovable(true);
        tabR_1 = new QWidget();
        tabR_1->setObjectName(QString::fromUtf8("tabR_1"));
        tabR->addTab(tabR_1, QString());
        tabR_2 = new QWidget();
        tabR_2->setObjectName(QString::fromUtf8("tabR_2"));
        tabR->addTab(tabR_2, QString());

        verticalLayout_2->addWidget(tabR);


        horizontalLayout->addWidget(panelRight);


        verticalLayout_3->addLayout(horizontalLayout);

        statusBar = new CrabDEPStatusBar(CrabDEPMainFrame);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        statusBar->setMinimumSize(QSize(0, 24));
        statusBar->setMaximumSize(QSize(16777215, 24));

        verticalLayout_3->addWidget(statusBar);


        retranslateUi(CrabDEPMainFrame);

        tabL->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(CrabDEPMainFrame);
    } // setupUi

    void retranslateUi(QWidget *CrabDEPMainFrame)
    {
        CrabDEPMainFrame->setWindowTitle(QApplication::translate("CrabDEPMainFrame", "CrabDEPMainFrame", 0, QApplication::UnicodeUTF8));
        tabL->setTabText(tabL->indexOf(tabL_1), QApplication::translate("CrabDEPMainFrame", "Tab 1", 0, QApplication::UnicodeUTF8));
        tabL->setTabText(tabL->indexOf(tabL_2), QApplication::translate("CrabDEPMainFrame", "Tab 2", 0, QApplication::UnicodeUTF8));
        tabR->setTabText(tabR->indexOf(tabR_1), QApplication::translate("CrabDEPMainFrame", "Tab 1", 0, QApplication::UnicodeUTF8));
        tabR->setTabText(tabR->indexOf(tabR_2), QApplication::translate("CrabDEPMainFrame", "Tab 2", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class CrabDEPMainFrame: public Ui_CrabDEPMainFrame {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CRABDEPMAINFRAME_H
